import { CharacterDef, CharacterId, Difficulty } from './types';

export const CHARACTERS: Record<CharacterId, CharacterDef> = {
  raka: {
    id: 'raka',
    name: 'Raka',
    role: 'Mahasiswa Pecinta Alam',
    description: 'Fisik terlatih, mampu bergerak cepat dan bertahan lebih lama di medan sulit.',
    perkDesc: 'Kecepatan gerak +10%, Kapasitas stamina +25%',
    skillName: 'Lari Kilat',
    skillDesc: 'Melaju dengan kecepatan ganda selama 1,5 detik.',
    skillCooldown: 25,
    speedMult: 1.10,
    staminaMult: 1.25,
    sanityRecoveryMult: 1.0,
    unlockedByDefault: true,
    requiredLevelToUnlock: 1,
    color: '#3b82f6',
  },
  sari: {
    id: 'sari',
    name: 'Sari',
    role: 'Perawat Berpengalaman',
    description: 'Mental stabil dan terbiasa dengan situasi darurat medis yang mengerikan.',
    perkDesc: 'Keberanian (Sanity) pulih 2x lebih cepat.',
    skillName: 'Tarik Napas',
    skillDesc: 'Diam 3 detik untuk memulihkan 30% Keberanian seketika.',
    skillCooldown: 30,
    speedMult: 1.0,
    staminaMult: 1.0,
    sanityRecoveryMult: 2.0,
    unlockedByDefault: true,
    requiredLevelToUnlock: 1,
    color: '#10b981',
  },
  joko: {
    id: 'joko',
    name: 'Pak Joko',
    role: 'Satpam Kawakan',
    description: 'Mantan penjaga malam berpengalaman yang menguasai peralatan senter.',
    perkDesc: 'Senter 40% lebih terang, baterai hemat 30%.',
    skillName: 'Sorot Terang',
    skillDesc: 'Kilatan cahaya tajam yang menghentikan hantu di depan selama 2 detik.',
    skillCooldown: 30,
    speedMult: 0.95,
    staminaMult: 1.05,
    sanityRecoveryMult: 1.1,
    unlockedByDefault: false,
    requiredLevelToUnlock: 2,
    color: '#f59e0b',
  },
  dewi: {
    id: 'dewi',
    name: 'Dewi',
    role: 'Anak Indigo',
    description: 'Peka terhadap aura astral di sekitarnya dan mampu merasakan kehadiran makhluk halus.',
    perkDesc: 'Peringatan bahaya hantu berbunyi 2 detik lebih awal.',
    skillName: 'Mata Batin',
    skillDesc: 'Melihat siluet hantu menembus dinding selama 4 detik (menguras 15% Keberanian).',
    skillCooldown: 35,
    speedMult: 1.0,
    staminaMult: 0.95,
    sanityRecoveryMult: 1.2,
    unlockedByDefault: false,
    requiredLevelToUnlock: 4,
    color: '#8b5cf6',
  },
};

/**
 * Noise radius in meters for different player and environment actions
 */
export function getNoiseRadius(action: 'CROUCH' | 'WALK' | 'RUN' | 'OPEN_DOOR' | 'SLAM_DOOR' | 'BREAK_BOTTLE'): number {
  switch (action) {
    case 'CROUCH':
      return 2.0;
    case 'WALK':
      return 6.0;
    case 'RUN':
      return 14.0;
    case 'OPEN_DOOR':
      return 8.0;
    case 'SLAM_DOOR':
      return 20.0;
    case 'BREAK_BOTTLE':
      return 18.0;
  }
}

/**
 * Calculates score upon completing a level
 */
export function calculateScore(
  baseScore: number,
  timeTaken: number,
  parTime: number,
  notesFound: number,
  totalNotes: number,
  timesCaught: number,
  cameraMultiplier: number = 1.0
): number {
  const timeBonus = Math.max(0, Math.round((parTime - timeTaken) * 5));
  const notesBonus = notesFound * 300;
  const stealthBonus = timesCaught === 0 ? 1000 : Math.max(0, 500 - timesCaught * 200);

  const rawScore = baseScore + timeBonus + notesBonus + stealthBonus;
  return Math.max(100, Math.round(rawScore * cameraMultiplier));
}

/**
 * Calculates 1-3 star rating for level completion
 */
export function calculateStars(
  completed: boolean,
  notesFound: number,
  timesCaught: number,
  timeTaken: number,
  parTime: number
): number {
  if (!completed) return 0;
  let stars = 1;
  // Second star: found at least 2 notes and caught at most once
  if (notesFound >= 2 && timesCaught <= 1) {
    stars = 2;
  }
  // Third star: found all 3 notes, never caught, and within par time + 60s
  if (notesFound >= 3 && timesCaught === 0 && timeTaken <= parTime + 60) {
    stars = 3;
  }
  return stars;
}

/**
 * Updates Keberanian (Sanity 0-100)
 */
export function updateSanity(
  currentSanity: number,
  inDarkness: boolean,
  distanceToGhost: number,
  isLookingAtGhost: boolean,
  isNearCandle: boolean,
  delta: number,
  recoveryMult: number = 1.0
): number {
  let rate = 0;

  if (isNearCandle) {
    rate += 6.0 * recoveryMult; // steady healing
  }

  if (inDarkness) {
    rate -= 1.5; // slow dread in dark
  } else if (!isNearCandle) {
    rate += 1.0 * recoveryMult; // baseline lit room recovery
  }

  if (distanceToGhost < 12.0) {
    const proximityThreat = (12.0 - distanceToGhost) / 12.0; // 0..1
    rate -= proximityThreat * 8.0;

    if (isLookingAtGhost) {
      rate -= proximityThreat * 12.0; // looking directly drains faster
    }
  }

  const nextSanity = Math.max(0, Math.min(100, currentSanity + rate * delta));
  return nextSanity;
}

/**
 * Updates Stamina (0-100)
 */
export function updateStamina(
  currentStamina: number,
  isRunning: boolean,
  isCrouching: boolean,
  isHoldingBreath: boolean,
  delta: number,
  maxStamina: number = 100
): number {
  let rate = 0;
  if (isHoldingBreath) {
    rate = -18.0; // drains during breath holding
  } else if (isRunning) {
    rate = -22.0; // drains during sprint
  } else if (isCrouching) {
    rate = 20.0; // fast recovery while crouched
  } else {
    rate = 14.0; // normal walking/idle recovery
  }

  return Math.max(0, Math.min(maxStamina, currentStamina + rate * delta));
}

/**
 * Verifies piano puzzle chord/melody in Level 2
 */
export function verifyPianoPuzzle(inputNotes: string[], targetMelody: string[]): boolean {
  if (inputNotes.length !== targetMelody.length) return false;
  return inputNotes.every((note, idx) => note.toUpperCase() === targetMelody[idx].toUpperCase());
}

/**
 * Evaluates ghost detection of player
 */
export function evaluateGhostDetection(
  ghostType: string,
  distance: number,
  playerSpeed: number,
  inSightCone: boolean,
  flashlightOn: boolean,
  flashlightAimedAtGhost: boolean,
  isCrouched: boolean,
  saltActiveDistance: number
): { detected: boolean; reason: 'SIGHT' | 'SOUND' | 'FLASHLIGHT' | 'NONE'; frozen?: boolean } {
  // If player is inside salt circle and ghost is near salt, ghost is repelled
  if (saltActiveDistance < 3.0 && ghostType !== 'NYAI_RATIH') {
    return { detected: false, reason: 'NONE' };
  }

  // Suster Ngesot is completely blind, relies 100% on hearing
  if (ghostType === 'SUSTER_NGESOT') {
    if (playerSpeed > 0.05) {
      const soundThreshold = isCrouched ? 2.5 : playerSpeed > 4.5 ? 16.0 : 8.0;
      if (distance <= soundThreshold) {
        return { detected: true, reason: 'SOUND' };
      }
    }
    return { detected: false, reason: 'NONE' };
  }

  // Noni Belanda freezes when hit by flashlight beam
  if (ghostType === 'NONI_BELANDA') {
    if (flashlightOn && flashlightAimedAtGhost && distance < 10.0) {
      return { detected: true, reason: 'FLASHLIGHT', frozen: true };
    }
    if (inSightCone && distance < 12.0) {
      return { detected: true, reason: 'SIGHT' };
    }
    if (playerSpeed > 4.5 && distance < 10.0) {
      return { detected: true, reason: 'SOUND' };
    }
    return { detected: false, reason: 'NONE' };
  }

  // Pocong & default
  if (inSightCone && distance < 14.0) {
    // Senter increases visibility range dramatically
    const maxVision = flashlightOn ? 18.0 : 10.0;
    if (distance <= maxVision) {
      return { detected: true, reason: 'SIGHT' };
    }
  }

  // Sound detection
  const soundRange = isCrouched ? 2.5 : playerSpeed > 4.5 ? 14.0 : 6.0;
  if (distance <= soundRange && playerSpeed > 0.1) {
    return { detected: true, reason: 'SOUND' };
  }

  return { detected: false, reason: 'NONE' };
}

/**
 * Returns lives count based on difficulty
 */
export function getDifficultyLives(difficulty: Difficulty): number {
  switch (difficulty) {
    case 'MUDAH':
      return 5;
    case 'NORMAL':
      return 3;
    case 'MIMPI_BURUK':
      return 1;
  }
}

/**
 * Validates player answer to a story lore riddle
 */
export function checkRiddleAnswer(correctIndex: number, selectedOptionIndex: number): boolean {
  return selectedOptionIndex === correctIndex;
}

/**
 * Decides whether the ghost should awaken from dormant state based on story progression
 * Ghost awakens only after player has uncovered lore notes, found a key, or solved a riddle.
 */
export function shouldAwakenGhost(foundNotesCount: number, foundKeysCount: number, solvedRiddlesCount: number): boolean {
  return foundNotesCount >= 1 || foundKeysCount >= 1 || solvedRiddlesCount >= 1;
}

/**
 * Robust circle vs AABB (axis-aligned bounding box) collision detection
 * Ensures player and entities cannot clip through walls or doors even at high speed or glancing angles.
 */
export function checkCircleBoxCollision(
  cx: number,
  cz: number,
  radius: number,
  minX: number,
  maxX: number,
  minZ: number,
  maxZ: number
): boolean {
  // Find closest point on the rectangle to the circle center
  const closestX = Math.max(minX, Math.min(cx, maxX));
  const closestZ = Math.max(minZ, Math.min(cz, maxZ));

  // Calculate distance between circle's center and this closest point
  const distanceX = cx - closestX;
  const distanceZ = cz - closestZ;

  // If distance is less than radius, collision occurred
  const distanceSquared = distanceX * distanceX + distanceZ * distanceZ;
  return distanceSquared < radius * radius;
}
