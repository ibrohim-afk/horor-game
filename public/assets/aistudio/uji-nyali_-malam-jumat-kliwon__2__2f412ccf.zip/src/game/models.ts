import * as THREE from 'three';
import { CharacterId } from './types';

// Pre-cached procedural textures
const textureCache: Record<string, THREE.CanvasTexture> = {};

export function getProceduralTexture(type: 'WOOD_FLOOR' | 'WALL_WOOD' | 'WALL_COLONIAL' | 'TILES_DIRTY' | 'BLOOD' | 'PORTRAIT' | 'BATIK'): THREE.CanvasTexture {
  if (textureCache[type]) return textureCache[type];

  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;

  if (type === 'WOOD_FLOOR') {
    // Rich aged Indonesian teak wood floorboards
    ctx.fillStyle = '#3a2517';
    ctx.fillRect(0, 0, 512, 512);

    // Individual planks with distinct tones
    const plankHeight = 64;
    for (let y = 0; y < 512; y += plankHeight) {
      const plankShade = Math.sin(y * 12.3) * 15;
      const r = Math.min(255, Math.max(0, 68 + plankShade));
      const g = Math.min(255, Math.max(0, 44 + plankShade * 0.7));
      const b = Math.min(255, Math.max(0, 28 + plankShade * 0.5));
      ctx.fillStyle = `rgb(${r},${g},${b})`;
      ctx.fillRect(0, y, 512, plankHeight - 3);

      // Dark groove between planks
      ctx.fillStyle = '#180e07';
      ctx.fillRect(0, y + plankHeight - 3, 512, 3);

      // Plank nail heads
      ctx.fillStyle = '#15100c';
      for (let x = 32; x < 512; x += 128) {
        ctx.beginPath();
        ctx.arc(x, y + 8, 3, 0, Math.PI * 2);
        ctx.arc(x, y + plankHeight - 10, 3, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // Organic wood grain fibers
    ctx.strokeStyle = 'rgba(28, 16, 10, 0.45)';
    ctx.lineWidth = 1.5;
    for (let i = 0; i < 80; i++) {
      ctx.beginPath();
      const startY = Math.random() * 512;
      ctx.moveTo(0, startY);
      ctx.bezierCurveTo(150, startY + (Math.random() - 0.5) * 20, 350, startY + (Math.random() - 0.5) * 20, 512, startY);
      ctx.stroke();
    }
  } else if (type === 'WALL_WOOD') {
    // Vertical Indonesian timber slats with wall framing
    ctx.fillStyle = '#422c1d';
    ctx.fillRect(0, 0, 512, 512);

    const slatWidth = 32;
    for (let x = 0; x < 512; x += slatWidth) {
      const shade = Math.sin(x * 7.5) * 12;
      ctx.fillStyle = `rgb(${72 + shade}, ${48 + shade * 0.7}, ${32 + shade * 0.5})`;
      ctx.fillRect(x, 0, slatWidth - 2, 512);

      // Dark joint gap
      ctx.fillStyle = '#1a1008';
      ctx.fillRect(x + slatWidth - 2, 0, 2, 512);
    }

    // Horizontal wooden structural beam
    ctx.fillStyle = '#2d1c11';
    ctx.fillRect(0, 240, 512, 32);
    ctx.fillStyle = '#160c06';
    ctx.fillRect(0, 238, 512, 2);
    ctx.fillRect(0, 272, 512, 2);
  } else if (type === 'WALL_COLONIAL') {
    // Dutch colonial plaster with moisture stains and peeling paint
    ctx.fillStyle = '#343f4a';
    ctx.fillRect(0, 0, 512, 512);

    // Damask decorative stencil
    ctx.strokeStyle = '#485766';
    ctx.lineWidth = 2.5;
    for (let x = 32; x < 512; x += 64) {
      for (let y = 32; y < 512; y += 64) {
        ctx.beginPath();
        ctx.arc(x, y, 14, 0, Math.PI * 2);
        ctx.stroke();
        ctx.strokeRect(x - 20, y - 20, 40, 40);
      }
    }

    // Mold and water stains
    ctx.fillStyle = 'rgba(20, 28, 35, 0.5)';
    for (let k = 0; k < 18; k++) {
      ctx.beginPath();
      ctx.arc(Math.random() * 512, Math.random() * 512, 20 + Math.random() * 40, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (type === 'TILES_DIRTY') {
    // Hospital green-gray cracked tile grid
    ctx.fillStyle = '#283832';
    ctx.fillRect(0, 0, 512, 512);

    ctx.strokeStyle = '#121c17';
    ctx.lineWidth = 4;
    for (let i = 0; i <= 512; i += 64) {
      ctx.beginPath();
      ctx.moveTo(i, 0); ctx.lineTo(i, 512);
      ctx.moveTo(0, i); ctx.lineTo(512, i);
      ctx.stroke();
    }

    // Cracks
    ctx.strokeStyle = '#0a100d';
    ctx.lineWidth = 2;
    for (let c = 0; c < 15; c++) {
      ctx.beginPath();
      const cx = Math.random() * 512;
      const cy = Math.random() * 512;
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + 25, cy + 18);
      ctx.lineTo(cx + 40, cy + 10);
      ctx.stroke();
    }
  } else if (type === 'PORTRAIT') {
    // Spooky antique sepia framed portrait of Juragan Wirawan
    ctx.fillStyle = '#3a2512';
    ctx.fillRect(0, 0, 512, 512);

    // Vintage inner photo border
    ctx.fillStyle = '#6b4f35';
    ctx.fillRect(40, 40, 432, 432);
    ctx.fillStyle = '#1c130b';
    ctx.fillRect(56, 56, 400, 400);

    // Silhouette of austere Victorian/Javanese patriarch
    ctx.fillStyle = '#453322';
    ctx.beginPath();
    ctx.arc(256, 190, 70, 0, Math.PI * 2); // Head
    ctx.fill();
    ctx.fillRect(156, 270, 200, 180); // Shoulders

    // Blangkon headwear silhouette
    ctx.fillStyle = '#221508';
    ctx.beginPath();
    ctx.arc(256, 170, 75, Math.PI, 0);
    ctx.fill();

    // Spooky piercing white pinprick eyes
    ctx.fillStyle = '#fef08a';
    ctx.beginPath();
    ctx.arc(235, 185, 3.5, 0, Math.PI * 2);
    ctx.arc(277, 185, 3.5, 0, Math.PI * 2);
    ctx.fill();
  } else if (type === 'BATIK') {
    // Traditional Javanese Batik Parang pattern for table runners and beds
    ctx.fillStyle = '#452614';
    ctx.fillRect(0, 0, 512, 512);

    ctx.strokeStyle = '#c59b6b';
    ctx.lineWidth = 4;
    for (let offset = -512; offset < 1024; offset += 48) {
      ctx.beginPath();
      ctx.moveTo(offset, 0);
      ctx.lineTo(offset + 512, 512);
      ctx.stroke();
    }
  } else {
    // Blood splatter
    ctx.fillStyle = 'rgba(0,0,0,0)';
    ctx.clearRect(0, 0, 512, 512);
    ctx.fillStyle = '#7f1d1d';
    ctx.beginPath();
    ctx.arc(256, 256, 80, 0, Math.PI * 2);
    ctx.fill();
    for (let b = 0; b < 24; b++) {
      ctx.beginPath();
      const angle = Math.random() * Math.PI * 2;
      const dist = 50 + Math.random() * 140;
      ctx.arc(256 + Math.cos(angle) * dist, 256 + Math.sin(angle) * dist, 6 + Math.random() * 16, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  textureCache[type] = texture;
  return texture;
}

/**
 * Creates Composite Human Player 3D Model with expressive silhouette, clothes, hair & flashlight
 */
export function createPlayerModel(charId: CharacterId = 'raka') {
  const root = new THREE.Group();
  root.name = 'player_root';

  const skinMat = new THREE.MeshStandardMaterial({
    color: charId === 'raka' ? 0xb5805d : charId === 'sari' ? 0xd49b78 : charId === 'joko' ? 0xa8714e : 0xc78a63,
    roughness: 0.7,
    metalness: 0.05,
  });

  const clothColor = charId === 'raka' ? 0x1e3a8a : charId === 'sari' ? 0x047857 : charId === 'joko' ? 0xb45309 : 0x6d28d9;
  const clothMat = new THREE.MeshStandardMaterial({ color: clothColor, roughness: 0.8, metalness: 0.1 });
  const pantsMat = new THREE.MeshStandardMaterial({ color: 0x1f2937, roughness: 0.85 });
  const shoeMat = new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.4, metalness: 0.3 });
  const metalMat = new THREE.MeshStandardMaterial({ color: 0x4b5563, roughness: 0.25, metalness: 0.85 });
  const lensMat = new THREE.MeshBasicMaterial({ color: 0xfef08a });

  // Main Torso
  const torsoGroup = new THREE.Group();
  torsoGroup.position.y = 1.0;
  root.add(torsoGroup);

  // Upper Jacket / Shirt with Collar
  const torso = new THREE.Mesh(new THREE.BoxGeometry(0.52, 0.7, 0.32), clothMat);
  torso.castShadow = true;
  torsoGroup.add(torso);

  // Inner Shirt accent
  const innerShirt = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.45, 0.05), new THREE.MeshStandardMaterial({ color: 0xe5e7eb, roughness: 0.9 }));
  innerShirt.position.set(0, 0.12, 0.15);
  torsoGroup.add(innerShirt);

  // Head and stylized hair/cap
  const headPivot = new THREE.Group();
  headPivot.position.set(0, 0.52, 0);
  torsoGroup.add(headPivot);

  const head = new THREE.Mesh(new THREE.SphereGeometry(0.18, 14, 12), skinMat);
  head.castShadow = true;
  headPivot.add(head);

  // Stylized Hair / Cap
  if (charId === 'joko') {
    // Security Guard Cap
    const cap = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.09, 14), new THREE.MeshStandardMaterial({ color: 0x1e3a8a, roughness: 0.5 }));
    cap.position.y = 0.15;
    headPivot.add(cap);

    const visor = new THREE.Mesh(new THREE.BoxGeometry(0.26, 0.02, 0.16), shoeMat);
    visor.position.set(0, 0.12, 0.16);
    headPivot.add(visor);
  } else {
    // Styled Hair
    const hair = new THREE.Mesh(
      new THREE.SphereGeometry(0.19, 12, 10),
      new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.9 })
    );
    hair.position.set(0, 0.05, -0.03);
    headPivot.add(hair);
  }

  // Left Arm (with shoulder joint)
  const leftArmPivot = new THREE.Group();
  leftArmPivot.position.set(-0.35, 0.28, 0);
  torsoGroup.add(leftArmPivot);

  const leftArm = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.06, 0.58, 8), clothMat);
  leftArm.geometry.translate(0, -0.28, 0);
  leftArm.castShadow = true;
  leftArmPivot.add(leftArm);

  const leftHand = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 8), skinMat);
  leftHand.position.set(0, -0.58, 0);
  leftArmPivot.add(leftHand);

  // Right Arm (holding flashlight raised forward)
  const rightArmPivot = new THREE.Group();
  rightArmPivot.position.set(0.35, 0.28, 0);
  torsoGroup.add(rightArmPivot);

  const rightArm = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.06, 0.58, 8), clothMat);
  rightArm.geometry.translate(0, -0.28, 0);
  rightArm.castShadow = true;
  rightArmPivot.add(rightArm);

  const rightHand = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 8), skinMat);
  rightHand.position.set(0, -0.58, 0);
  rightArmPivot.add(rightHand);

  // Flashlight prop mounted firmly to right hand
  const flashGroup = new THREE.Group();
  flashGroup.position.set(0, -0.58, 0.14);
  flashGroup.rotation.x = Math.PI / 2;
  rightArmPivot.add(flashGroup);

  const flashCylinder = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 0.26, 10), metalMat);
  flashGroup.add(flashCylinder);

  const flashBezel = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.045, 0.1, 10), metalMat);
  flashBezel.position.y = 0.14;
  flashGroup.add(flashBezel);

  const flashLens = new THREE.Mesh(new THREE.CircleGeometry(0.065, 10), lensMat);
  flashLens.position.y = 0.191;
  flashLens.rotation.x = -Math.PI / 2;
  flashGroup.add(flashLens);

  // Legs with boots
  const leftLegPivot = new THREE.Group();
  leftLegPivot.position.set(-0.16, -0.35, 0);
  torsoGroup.add(leftLegPivot);

  const leftLeg = new THREE.Mesh(new THREE.CylinderGeometry(0.085, 0.07, 0.65, 8), pantsMat);
  leftLeg.geometry.translate(0, -0.3, 0);
  leftLeg.castShadow = true;
  leftLegPivot.add(leftLeg);

  const leftBoot = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.12, 0.24), shoeMat);
  leftBoot.position.set(0, -0.62, 0.06);
  leftLegPivot.add(leftBoot);

  const rightLegPivot = new THREE.Group();
  rightLegPivot.position.set(0.16, -0.35, 0);
  torsoGroup.add(rightLegPivot);

  const rightLeg = new THREE.Mesh(new THREE.CylinderGeometry(0.085, 0.07, 0.65, 8), pantsMat);
  rightLeg.geometry.translate(0, -0.3, 0);
  rightLeg.castShadow = true;
  rightLegPivot.add(rightLeg);

  const rightBoot = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.12, 0.24), shoeMat);
  rightBoot.position.set(0, -0.62, 0.06);
  rightLegPivot.add(rightBoot);

  return {
    root,
    torsoGroup,
    headPivot,
    leftArmPivot,
    rightArmPivot,
    leftLegPivot,
    rightLegPivot,
    flashGroup,
  };
}

/**
 * Creates Authentic Indonesian Pocong Model
 */
export function createPocongModel() {
  const group = new THREE.Group();
  group.name = 'ghost_pocong';

  const shroudMat = new THREE.MeshStandardMaterial({
    color: 0xdfded8, // stained dusty burial shroud
    roughness: 0.95,
    metalness: 0.02,
  });
  const faceMat = new THREE.MeshStandardMaterial({
    color: 0x222222, // blackened rotting face
    roughness: 0.9,
  });
  const ropeMat = new THREE.MeshStandardMaterial({
    color: 0x785d3f,
    roughness: 0.85,
  });

  // Tapered wrapped shroud body
  const bodyGeom = new THREE.CylinderGeometry(0.36, 0.24, 1.9, 14);
  bodyGeom.translate(0, 0.95, 0);
  const body = new THREE.Mesh(bodyGeom, shroudMat);
  body.castShadow = true;
  group.add(body);

  // Top knot bundle with rope tie
  const topKnot = new THREE.Mesh(new THREE.SphereGeometry(0.18, 10, 10), shroudMat);
  topKnot.scale.set(1, 1.6, 1);
  topKnot.position.y = 2.05;
  group.add(topKnot);

  const topRope = new THREE.Mesh(new THREE.TorusGeometry(0.15, 0.045, 8, 14), ropeMat);
  topRope.position.y = 1.9;
  topRope.rotation.x = Math.PI / 2;
  group.add(topRope);

  // Neck tie rope
  const neckRope = new THREE.Mesh(new THREE.TorusGeometry(0.24, 0.04, 8, 14), ropeMat);
  neckRope.position.y = 1.62;
  neckRope.rotation.x = Math.PI / 2;
  group.add(neckRope);

  // Ankle / feet tie rope
  const feetRope = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.045, 8, 14), ropeMat);
  feetRope.position.y = 0.18;
  feetRope.rotation.x = Math.PI / 2;
  group.add(feetRope);

  // Open slit revealing horrifying decayed face
  const faceOpening = new THREE.Mesh(new THREE.SphereGeometry(0.15, 10, 8), faceMat);
  faceOpening.scale.set(0.9, 1.3, 0.4);
  faceOpening.position.set(0, 1.48, 0.25);
  group.add(faceOpening);

  // Red spectral embers inside eye sockets
  const eyeMat = new THREE.MeshBasicMaterial({ color: 0xff0000 });
  const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.025, 6, 6), eyeMat);
  eyeL.position.set(-0.05, 1.52, 0.35);
  const eyeR = new THREE.Mesh(new THREE.SphereGeometry(0.025, 6, 6), eyeMat);
  eyeR.position.set(0.05, 1.52, 0.35);
  group.add(eyeL, eyeR);

  // Eerie red subtle glow
  const glow = new THREE.PointLight(0xff2200, 0.8, 4.0);
  glow.position.set(0, 1.5, 0.4);
  group.add(glow);

  return group;
}

/**
 * Creates Dutch Colonial Ghost: Noni Belanda
 */
export function createNoniBelandaModel() {
  const group = new THREE.Group();
  group.name = 'ghost_noni';

  const dressMat = new THREE.MeshStandardMaterial({
    color: 0xb0c4de,
    roughness: 0.6,
    metalness: 0.15,
    transparent: true,
    opacity: 0.85,
  });
  const laceMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    roughness: 0.4,
    transparent: true,
    opacity: 0.9,
  });
  const skinMat = new THREE.MeshStandardMaterial({
    color: 0xf5f5f5,
    roughness: 0.4,
  });
  const hairMat = new THREE.MeshStandardMaterial({
    color: 0xeab308, // golden blonde curls
    roughness: 0.7,
  });

  // Flowing Victorian hoop skirt
  const skirt = new THREE.Mesh(new THREE.ConeGeometry(0.75, 1.4, 16, 1, true), dressMat);
  skirt.position.y = 0.7;
  group.add(skirt);

  // Skirt lace trim ruffle
  const ruffle = new THREE.Mesh(new THREE.TorusGeometry(0.72, 0.05, 6, 16), laceMat);
  ruffle.position.y = 0.05;
  ruffle.rotation.x = Math.PI / 2;
  group.add(ruffle);

  // Upper Corset
  const corset = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.3, 0.55, 12), dressMat);
  corset.position.y = 1.5;
  group.add(corset);

  // Pale Head
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.18, 12, 12), skinMat);
  head.position.y = 1.9;
  group.add(head);

  // Golden Ringlet Curls
  const curlL = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 0.45, 8), hairMat);
  curlL.position.set(-0.18, 1.8, 0);
  const curlR = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 0.45, 8), hairMat);
  curlR.position.set(0.18, 1.8, 0);
  group.add(curlL, curlR);

  // Floating ghost arms reaching out
  const armL = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.04, 0.65, 8), dressMat);
  armL.position.set(-0.4, 1.5, 0.25);
  armL.rotation.x = Math.PI / 3.5;
  armL.rotation.z = Math.PI / 6;

  const armR = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.04, 0.65, 8), dressMat);
  armR.position.set(0.4, 1.5, 0.25);
  armR.rotation.x = Math.PI / 3.5;
  armR.rotation.z = -Math.PI / 6;

  group.add(armL, armR);

  // Spectral Blue Ambient Aura
  const ghostGlow = new THREE.PointLight(0x60a5fa, 1.5, 6.0);
  ghostGlow.position.y = 1.6;
  group.add(ghostGlow);

  return group;
}

/**
 * Creates Suster Ngesot Crawling Ghost
 */
export function createSusterNgesotModel() {
  const group = new THREE.Group();
  group.name = 'ghost_suster';

  const gownMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.9 });
  const capMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.7 });
  const crossMat = new THREE.MeshBasicMaterial({ color: 0x991b1b });

  // Crawling body horizontal along floor
  const body = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.28, 0.85), gownMat);
  body.position.set(0, 0.18, 0);
  group.add(body);

  // Head peering forward
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.17, 10, 10), gownMat);
  head.position.set(0, 0.34, 0.48);
  group.add(head);

  // Nurse Cap with Red Cross
  const cap = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.08, 0.14), capMat);
  cap.position.set(0, 0.46, 0.44);
  group.add(cap);

  const cross = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.05, 0.02), crossMat);
  cross.position.set(0, 0.46, 0.515);
  group.add(cross);

  // Crawling arms forward
  const armL = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.11, 0.55), gownMat);
  armL.position.set(-0.3, 0.12, 0.6);
  const armR = new THREE.Mesh(new THREE.BoxGeometry(0.11, 0.11, 0.55), gownMat);
  armR.position.set(0.3, 0.12, 0.6);
  group.add(armL, armR);

  // Twisted limp legs trailing behind
  const legs = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.14, 0.75), gownMat);
  legs.position.set(0, 0.1, -0.65);
  group.add(legs);

  return group;
}

/**
 * Creates Traditional Javanese Antique Dining Table with Chairs & Tea Set
 */
export function createTableAndChairs() {
  const group = new THREE.Group();
  group.name = 'prop_table_set';

  const woodMat = new THREE.MeshStandardMaterial({
    map: getProceduralTexture('WOOD_FLOOR'),
    roughness: 0.7,
    metalness: 0.1,
  });
  const clothMat = new THREE.MeshStandardMaterial({
    map: getProceduralTexture('BATIK'),
    roughness: 0.9,
  });
  const teaMat = new THREE.MeshStandardMaterial({
    color: 0x4d7c0f, // green mottled enamelware cup
    roughness: 0.4,
    metalness: 0.5,
  });

  // Table Top
  const tableTop = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.08, 1.0), woodMat);
  tableTop.position.y = 0.8;
  tableTop.castShadow = true;
  group.add(tableTop);

  // Batik Runner
  const runner = new THREE.Mesh(new THREE.BoxGeometry(1.64, 0.01, 0.4), clothMat);
  runner.position.set(0, 0.845, 0);
  group.add(runner);

  // 4 Legs
  const legGeom = new THREE.CylinderGeometry(0.05, 0.04, 0.8, 8);
  for (const [x, z] of [[-0.7, -0.4], [0.7, -0.4], [-0.7, 0.4], [0.7, 0.4]]) {
    const leg = new THREE.Mesh(legGeom, woodMat);
    leg.position.set(x, 0.4, z);
    leg.castShadow = true;
    group.add(leg);
  }

  // Antique Javanese Enamelware Teapot & Cup
  const teapot = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 0.16, 8), teaMat);
  teapot.position.set(0, 0.93, 0);
  group.add(teapot);

  const cup = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.04, 0.09, 8), teaMat);
  cup.position.set(0.25, 0.89, 0);
  group.add(cup);

  // Two Wooden Chairs
  for (const zSide of [-0.75, 0.75]) {
    const chair = new THREE.Group();
    chair.position.set(0, 0, zSide);
    if (zSide > 0) chair.rotation.y = Math.PI;

    const seat = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.05, 0.5), woodMat);
    seat.position.y = 0.45;
    chair.add(seat);

    const backrest = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.55, 0.05), woodMat);
    backrest.position.set(0, 0.75, -0.22);
    chair.add(backrest);

    for (const [cx, cz] of [[-0.2, -0.2], [0.2, -0.2], [-0.2, 0.2], [0.2, 0.2]]) {
      const cLeg = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.45, 6), woodMat);
      cLeg.position.set(cx, 0.225, cz);
      chair.add(cLeg);
    }
    group.add(chair);
  }

  return group;
}

/**
 * Creates Traditional Antique Wooden Bed with Pillow & Batik Blanket
 */
export function createAntiqueBed() {
  const group = new THREE.Group();
  group.name = 'prop_antique_bed';

  const woodMat = new THREE.MeshStandardMaterial({
    map: getProceduralTexture('WOOD_FLOOR'),
    roughness: 0.75,
  });
  const sheetMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, roughness: 0.9 });
  const blanketMat = new THREE.MeshStandardMaterial({
    map: getProceduralTexture('BATIK'),
    roughness: 0.85,
  });

  // Bed Frame
  const frame = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.25, 2.2), woodMat);
  frame.position.set(0, 0.35, 0);
  frame.castShadow = true;
  group.add(frame);

  // Headboard
  const headboard = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.9, 0.1), woodMat);
  headboard.position.set(0, 0.8, -1.05);
  group.add(headboard);

  // Mattress
  const mattress = new THREE.Mesh(new THREE.BoxGeometry(1.45, 0.2, 2.05), sheetMat);
  mattress.position.set(0, 0.55, 0);
  group.add(mattress);

  // Batik Blanket folded across lower half
  const blanket = new THREE.Mesh(new THREE.BoxGeometry(1.48, 0.03, 1.2), blanketMat);
  blanket.position.set(0, 0.67, 0.35);
  group.add(blanket);

  // Pillows
  const pillowGeom = new THREE.BoxGeometry(0.5, 0.12, 0.35);
  const pillow1 = new THREE.Mesh(pillowGeom, sheetMat);
  pillow1.position.set(-0.35, 0.7, -0.75);
  const pillow2 = new THREE.Mesh(pillowGeom, sheetMat);
  pillow2.position.set(0.35, 0.7, -0.75);
  group.add(pillow1, pillow2);

  return group;
}

/**
 * Creates Framed Sepia Ancestor Portrait of Juragan Wirawan for Walls
 */
export function createPortraitPainting() {
  const group = new THREE.Group();
  group.name = 'prop_portrait';

  const frameMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.35, metalness: 0.8 });
  const pictureMat = new THREE.MeshStandardMaterial({ map: getProceduralTexture('PORTRAIT'), roughness: 0.5 });

  const frame = new THREE.Mesh(new THREE.BoxGeometry(0.85, 1.15, 0.06), frameMat);
  group.add(frame);

  const picture = new THREE.Mesh(new THREE.PlaneGeometry(0.72, 1.0), pictureMat);
  picture.position.z = 0.035;
  group.add(picture);

  return group;
}

/**
 * Creates Indonesian Hanging Kerosene Petromak Lantern with Warm Flicker
 */
export function createKeroseneLamp() {
  const group = new THREE.Group();
  group.name = 'prop_kerosene_lamp';

  const brassMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.3, metalness: 0.85 });
  const glassMat = new THREE.MeshStandardMaterial({
    color: 0xfef3c7,
    roughness: 0.1,
    transparent: true,
    opacity: 0.65,
  });

  // Top Hood & Ring
  const hood = new THREE.Mesh(new THREE.ConeGeometry(0.24, 0.12, 10), brassMat);
  hood.position.y = 0.35;
  group.add(hood);

  // Glass Globe
  const glass = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.14, 0.3, 10), glassMat);
  glass.position.y = 0.15;
  group.add(glass);

  // Fuel Base
  const base = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.18, 0.15, 10), brassMat);
  base.position.y = -0.08;
  group.add(base);

  // Warm glowing point light with flickering flame
  const light = new THREE.PointLight(0xff9922, 1.8, 14);
  light.position.y = 0.15;
  light.castShadow = true;
  group.add(light);

  return { group, light };
}

/**
 * Creates Altar Sesajen Table with Incense and Offerings
 */
export function createAltarSesajen() {
  const group = new THREE.Group();
  group.name = 'prop_altar';

  const woodMat = new THREE.MeshStandardMaterial({
    map: getProceduralTexture('WOOD_FLOOR'),
    roughness: 0.8,
  });
  const brassMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.3, metalness: 0.8 });
  const clothMat = new THREE.MeshStandardMaterial({ color: 0x991b1b, roughness: 0.9 }); // crimson cloth

  // Small altar table
  const table = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.7, 0.8), woodMat);
  table.position.y = 0.35;
  table.castShadow = true;
  group.add(table);

  // Crimson cloth runner
  const cloth = new THREE.Mesh(new THREE.BoxGeometry(1.24, 0.02, 0.84), clothMat);
  cloth.position.y = 0.71;
  group.add(cloth);

  // Brass Incense Holder (Tempat Dupa)
  const incense = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.05, 0.12, 8), brassMat);
  incense.position.set(0, 0.78, 0);
  group.add(incense);

  // Flower Offering Bowl (Baskom Sesajen Bunga Tujuh Rupa)
  const bowl = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.1, 0.08, 10), brassMat);
  bowl.position.set(0.3, 0.75, 0);
  group.add(bowl);

  // Two Red Altar Candles with flickering light
  for (const xOff of [-0.35, 0.35]) {
    const candle = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 0.25, 6), new THREE.MeshStandardMaterial({ color: 0xdc2626 }));
    candle.position.set(xOff, 0.82, -0.2);
    group.add(candle);

    const flame = new THREE.Mesh(new THREE.ConeGeometry(0.02, 0.06, 6), new THREE.MeshBasicMaterial({ color: 0xf59e0b }));
    flame.position.set(xOff, 0.96, -0.2);
    group.add(flame);
  }

  const altarLight = new THREE.PointLight(0xff5511, 1.2, 6);
  altarLight.position.set(0, 1.0, 0);
  group.add(altarLight);

  return group;
}

/**
 * Creates Wardrobe (Lemari Jati) Hiding Spot
 */
export function createWardrobe() {
  const group = new THREE.Group();
  group.name = 'prop_wardrobe';

  const woodMat = new THREE.MeshStandardMaterial({
    map: getProceduralTexture('WOOD_FLOOR'),
    roughness: 0.75,
    metalness: 0.1,
  });
  const handleMat = new THREE.MeshStandardMaterial({
    color: 0xb45309,
    roughness: 0.3,
    metalness: 0.85,
  });

  // Carved wooden frame
  const frame = new THREE.Mesh(new THREE.BoxGeometry(1.3, 2.3, 0.75), woodMat);
  frame.position.y = 1.15;
  frame.castShadow = true;
  group.add(frame);

  // Ornate Top Crown
  const crown = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.12, 0.82), woodMat);
  crown.position.y = 2.36;
  group.add(crown);

  // Door handles
  const handleL = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.14, 6), handleMat);
  handleL.position.set(-0.07, 1.15, 0.39);
  const handleR = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.14, 6), handleMat);
  handleR.position.set(0.07, 1.15, 0.39);
  group.add(handleL, handleR);

  return group;
}

/**
 * Creates Grand Piano for Level 2
 */
export function createGrandPiano() {
  const group = new THREE.Group();
  group.name = 'prop_piano';

  const lacquerMat = new THREE.MeshStandardMaterial({
    color: 0x0f172a,
    roughness: 0.2,
    metalness: 0.7,
  });
  const keyWhite = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.4 });

  // Main Piano Body
  const body = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.5, 1.2), lacquerMat);
  body.position.set(0, 0.9, 0);
  body.castShadow = true;
  group.add(body);

  // Keyboard shelf
  const shelf = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.12, 0.25), lacquerMat);
  shelf.position.set(0, 0.8, 0.65);
  group.add(shelf);

  // Keyboard keys
  const keys = new THREE.Mesh(new THREE.BoxGeometry(1.3, 0.04, 0.2), keyWhite);
  keys.position.set(0, 0.87, 0.65);
  group.add(keys);

  // 3 Legs
  const legGeom = new THREE.CylinderGeometry(0.06, 0.04, 0.7, 8);
  for (const [x, z] of [[-0.65, 0.45], [0.65, 0.45], [0, -0.45]]) {
    const leg = new THREE.Mesh(legGeom, lacquerMat);
    leg.position.set(x, 0.35, z);
    group.add(leg);
  }

  return group;
}

/**
 * Creates Fuse Box for Level 2
 */
export function createFuseBox() {
  const group = new THREE.Group();
  group.name = 'prop_fuse_box';

  const metalMat = new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.4, metalness: 0.7 });
  const redLamp = new THREE.MeshBasicMaterial({ color: 0xef4444 });

  const box = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.6, 0.15), metalMat);
  box.position.y = 1.4;
  group.add(box);

  const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.04, 8, 8), redLamp);
  lamp.position.set(0, 1.55, 0.08);
  group.add(lamp);

  return group;
}

/**
 * Creates Candle Checkpoint with warm flickering point light
 */
export function createCandleCheckpoint() {
  const group = new THREE.Group();
  group.name = 'prop_candle';

  const waxMat = new THREE.MeshStandardMaterial({ color: 0xfef3c7, roughness: 0.6 });
  const flameMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b });

  // Wooden stool
  const stool = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.25, 0.4, 8), waxMat);
  stool.position.y = 0.2;
  group.add(stool);

  // Candle stick
  const candle = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.2, 8), waxMat);
  candle.position.y = 0.5;
  group.add(candle);

  // Flame teardrop
  const flame = new THREE.Mesh(new THREE.ConeGeometry(0.03, 0.08, 6), flameMat);
  flame.position.y = 0.64;
  group.add(flame);

  // Warm light
  const light = new THREE.PointLight(0xf59e0b, 1.5, 8.0);
  light.position.y = 0.66;
  group.add(light);

  return { group, light, flame };
}

/**
 * Creates Interactive Door with Pivot
 */
export function createDoor() {
  const frameGroup = new THREE.Group();
  frameGroup.name = 'door_frame';

  const woodMat = new THREE.MeshStandardMaterial({
    map: getProceduralTexture('WOOD_FLOOR'),
    roughness: 0.8,
    metalness: 0.05,
  });
  const knobMat = new THREE.MeshStandardMaterial({
    color: 0xd97706,
    roughness: 0.2,
    metalness: 0.9,
  });

  // Door Frame Trim
  const topTrim = new THREE.Mesh(new THREE.BoxGeometry(1.24, 0.1, 0.14), woodMat);
  topTrim.position.set(0, 2.25, 0);
  frameGroup.add(topTrim);

  // Pivot positioned on the door edge for natural swinging
  const doorPivot = new THREE.Group();
  doorPivot.position.set(-0.5, 0, 0);
  frameGroup.add(doorPivot);

  const panel = new THREE.Mesh(new THREE.BoxGeometry(1.0, 2.2, 0.08), woodMat);
  panel.position.set(0.5, 1.1, 0);
  panel.castShadow = true;
  doorPivot.add(panel);

  const knob = new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 8), knobMat);
  knob.position.set(0.9, 1.05, 0.06);
  doorPivot.add(knob);

  return { frameGroup, doorPivot, isOpen: false, isLocked: false };
}

/**
 * Creates Floating Dust Particles in the Air
 */
export function createDustParticles(count = 150) {
  const geom = new THREE.BufferGeometry();
  const positions = new Float32Array(count * 3);

  for (let i = 0; i < count; i++) {
    positions[i * 3] = (Math.random() - 0.5) * 35;
    positions[i * 3 + 1] = Math.random() * 3.5;
    positions[i * 3 + 2] = (Math.random() - 0.5) * 35;
  }

  geom.setAttribute('position', new THREE.BufferAttribute(positions, 3));

  const mat = new THREE.PointsMaterial({
    color: 0xedd6b4,
    size: 0.04,
    transparent: true,
    opacity: 0.5,
  });

  return new THREE.Points(geom, mat);
}
