import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateScore,
  calculateStars,
  getNoiseRadius,
  updateSanity,
  updateStamina,
  verifyPianoPuzzle,
  evaluateGhostDetection,
  getDifficultyLives,
  checkRiddleAnswer,
  shouldAwakenGhost,
  checkCircleBoxCollision,
  CHARACTERS
} from './rules.ts';

test('noise radius increases with high-impact actions', () => {
  const crouchRadius = getNoiseRadius('CROUCH');
  const walkRadius = getNoiseRadius('WALK');
  const runRadius = getNoiseRadius('RUN');
  const slamRadius = getNoiseRadius('SLAM_DOOR');

  assert.equal(crouchRadius, 2.0);
  assert.equal(walkRadius, 6.0);
  assert.equal(runRadius, 14.0);
  assert.equal(slamRadius, 20.0);
  assert.ok(runRadius > walkRadius);
  assert.ok(slamRadius > runRadius);
});

test('score calculation includes camera multipliers and stealth bonuses', () => {
  // First person multiplier = 1.5
  const fpScore = calculateScore(1000, 180, 240, 3, 3, 0, 1.5);
  // Top down multiplier = 1.0
  const tdScore = calculateScore(1000, 180, 240, 3, 3, 0, 1.0);

  assert.ok(fpScore > tdScore);
  assert.equal(fpScore, Math.round(tdScore * 1.5));
});

test('level star rating rewards flawless execution', () => {
  // 3 notes, 0 caught, within time
  assert.equal(calculateStars(true, 3, 0, 200, 240), 3);
  // 2 notes, 1 caught
  assert.equal(calculateStars(true, 2, 1, 200, 240), 2);
  // 1 note, 2 caught
  assert.equal(calculateStars(true, 1, 2, 200, 240), 1);
  // Not completed
  assert.equal(calculateStars(false, 3, 0, 200, 240), 0);
});

test('sanity drains in darkness and heals near candle', () => {
  const initial = 80;
  // In darkness, no ghost
  const drained = updateSanity(initial, true, 20, false, false, 2.0, 1.0);
  assert.ok(drained < initial);

  // Near candle
  const healed = updateSanity(initial, false, 20, false, true, 2.0, 1.0);
  assert.ok(healed > initial);
});

test('stamina consumes when running and regenerates when crouching', () => {
  const max = 100;
  const running = updateStamina(max, true, false, false, 1.0, max);
  assert.ok(running < max);

  const crouchRecover = updateStamina(40, false, true, false, 1.0, max);
  assert.ok(crouchRecover > 40);
});

test('piano puzzle correctly validates note order', () => {
  const target = ['C4', 'E4', 'G4', 'B4'];
  assert.equal(verifyPianoPuzzle(['C4', 'E4', 'G4', 'B4'], target), true);
  assert.equal(verifyPianoPuzzle(['C4', 'G4', 'E4', 'B4'], target), false);
  assert.equal(verifyPianoPuzzle(['C4', 'E4'], target), false);
});

test('suster ngesot is blind but detects loud sound', () => {
  // High speed running at 8m distance
  const runningRes = evaluateGhostDetection('SUSTER_NGESOT', 8.0, 5.0, true, true, true, false, 99);
  assert.equal(runningRes.detected, true);
  assert.equal(runningRes.reason, 'SOUND');

  // Crouched idle in front of her
  const crouchedRes = evaluateGhostDetection('SUSTER_NGESOT', 5.0, 0.0, true, true, true, true, 99);
  assert.equal(crouchedRes.detected, false);
});

test('noni belanda freezes when hit by flashlight beam', () => {
  const res = evaluateGhostDetection('NONI_BELANDA', 6.0, 0.0, false, true, true, false, 99);
  assert.equal(res.detected, true);
  assert.equal(res.frozen, true);
});

test('difficulty lives scale correctly', () => {
  assert.equal(getDifficultyLives('MUDAH'), 5);
  assert.equal(getDifficultyLives('NORMAL'), 3);
  assert.equal(getDifficultyLives('MIMPI_BURUK'), 1);
});

test('characters have unique distinct perks and skills', () => {
  assert.equal(CHARACTERS.raka.speedMult, 1.10);
  assert.equal(CHARACTERS.sari.sanityRecoveryMult, 2.0);
  assert.equal(CHARACTERS.joko.unlockedByDefault, false);
  assert.equal(CHARACTERS.dewi.requiredLevelToUnlock, 4);
});

test('riddle answer checks correctly against correct index', () => {
  assert.equal(checkRiddleAnswer(0, 0), true);
  assert.equal(checkRiddleAnswer(0, 1), false);
  assert.equal(checkRiddleAnswer(2, 2), true);
});

test('ghost remains dormant until player discovers clues or keys', () => {
  // 0 clues, 0 keys, 0 riddles solved -> ghost sleeps
  assert.equal(shouldAwakenGhost(0, 0, 0), false);
  // Found 1 lore note -> awakens!
  assert.equal(shouldAwakenGhost(1, 0, 0), true);
  // Found 1 key -> awakens!
  assert.equal(shouldAwakenGhost(0, 1, 0), true);
});

test('circle box collision prevents clipping into walls and closed doors', () => {
  // Wall from x: 4 to 6, z: 4 to 6
  // Player at (4.5, 4.5) with radius 0.4 -> inside/colliding
  assert.equal(checkCircleBoxCollision(4.5, 4.5, 0.4, 4, 6, 4, 6), true);

  // Player at (3.7, 5.0) with radius 0.4 -> distance to wall edge (4.0) is 0.3 < 0.4 -> colliding!
  assert.equal(checkCircleBoxCollision(3.7, 5.0, 0.4, 4, 6, 4, 6), true);

  // Player at (2.0, 5.0) with radius 0.4 -> distance is 2.0 > 0.4 -> safe!
  assert.equal(checkCircleBoxCollision(2.0, 5.0, 0.4, 4, 6, 4, 6), false);
});

