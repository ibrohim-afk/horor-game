import * as THREE from 'three';
import {
  CameraMode,
  CharacterId,
  Difficulty,
  GhostState,
  InventoryItem,
  LevelConfig,
  LoreNote,
  StoryRiddle,
} from './types';
import {
  CHARACTERS,
  checkCircleBoxCollision,
  checkRiddleAnswer,
  evaluateGhostDetection,
  getNoiseRadius,
  shouldAwakenGhost,
  updateSanity,
  updateStamina,
  verifyPianoPuzzle,
} from './rules';
import {
  createCandleCheckpoint,
  createDoor,
  createFuseBox,
  createGrandPiano,
  createPlayerModel,
  createPocongModel,
  createNoniBelandaModel,
  createSusterNgesotModel,
  createWardrobe,
  createTableAndChairs,
  createAntiqueBed,
  createAltarSesajen,
  createPortraitPainting,
  createKeroseneLamp,
  createDustParticles,
  getProceduralTexture,
} from './models';
import { soundManager } from './audio';
import { AIDirector } from './director';

export interface GameEngineCallbacks {
  onSanityChange: (sanity: number) => void;
  onStaminaChange: (stamina: number) => void;
  onBatteryChange: (battery: number) => void;
  onInventoryChange: (items: InventoryItem[]) => void;
  onObjectiveUpdate: (objectives: LevelConfig['objectives']) => void;
  onLivesChange: (lives: number) => void;
  onScoreChange: (score: number) => void;
  onCameraChange: (mode: CameraMode) => void;
  onInteractionPrompt: (prompt: string | null) => void;
  onGhostDetectedChange: (isChasing: boolean, threatDistance: number) => void;
  onNoteFound: (note: LoreNote) => void;
  onPianoPuzzleOpen: (isOpen: boolean) => void;
  onOpenRiddle: (riddle: StoryRiddle) => void;
  onGameOver: (reason: string) => void;
  onLevelComplete: (score: number, stars: number, foundNoteIds: string[]) => void;
  onParanormalNotification: (text: string) => void;
  onHidingStateChange: (isHiding: boolean) => void;
}

export class GameEngine {
  private container: HTMLDivElement;
  private callbacks: GameEngineCallbacks;

  // Three.js core
  private renderer!: THREE.WebGLRenderer;
  private scene!: THREE.Scene;
  private camera!: THREE.PerspectiveCamera;
  private clock = new THREE.Clock();

  // Rendering guard
  private isSoftwareGl = false;
  private animationFrameId: number | null = null;
  private isDisposed = false;
  private isPaused = false;

  // Active Level & Player
  private levelConfig!: LevelConfig;
  private characterId: CharacterId = 'raka';
  private difficulty: Difficulty = 'NORMAL';
  private cameraMode: CameraMode = 'FIRST_PERSON';

  // Player state
  private playerX = 3;
  private playerZ = 3;
  private playerRotY = 0;
  private playerPitch = 0; // vertical camera tilt
  private sanity = 100;
  private stamina = 100;
  private battery = 100;
  private isFlashlightOn = true;
  private lives = 3;
  private score = 0;
  private elapsedLevelTime = 0;
  private isHiding = false;
  private isHoldingBreath = false;
  private isPossessed = false;
  private possessedTimer = 0;
  private skillCooldownTimer = 0;

  // 3D Player Mesh Rig
  private playerRig!: ReturnType<typeof createPlayerModel>;
  private flashlightSpot!: THREE.SpotLight;
  private flashlightTarget!: THREE.Object3D;

  // Ghost entity
  private ghostMesh: THREE.Group | null = null;
  private ghostX = 8;
  private ghostZ = 8;
  private ghostState: GhostState = 'DORMANT';
  private ghostTimer = 0;
  private ghostTargetX = 8;
  private ghostTargetZ = 8;
  private ghostStunTimer = 0;
  private ghostHopAnim = 0;
  private lastGhostFootstepTime = 0;

  // Level World Map
  private grid: string[] = [];
  private walls: THREE.Box3[] = [];
  private interactiveDoors: Array<{ frame: THREE.Group; pivot: THREE.Group; isOpen: boolean; x: number; z: number }> = [];
  private hidingSpots: Array<{ mesh: THREE.Group; x: number; z: number }> = [];
  private candleProps: Array<{ light: THREE.PointLight; flame: THREE.Mesh; x: number; z: number; isLit: boolean; burnTime: number }> = [];
  private pickupItems: Array<{ id: string; mesh: THREE.Group; x: number; z: number; type: string; name: string; collected: boolean }> = [];
  private visitedGridTiles: Set<string> = new Set();
  private solvedRiddleIds: Set<string> = new Set();
  private activeRiddleTriggers: Array<{ riddle: StoryRiddle; x: number; z: number }> = [];

  // Special Level Props
  private pianoMesh: THREE.Group | null = null;
  private fuseBoxMesh: THREE.Group | null = null;
  private isFuseBoxOn = false;
  private pianoInputNotes: string[] = [];
  private activeSaltCircle: { mesh: THREE.Mesh; x: number; z: number; expireTime: number } | null = null;

  // Inventory
  private inventory: InventoryItem[] = [];
  private collectedNotesThisRun: string[] = [];

  // Director
  private director: AIDirector;

  // Input states
  private keysPressed: Record<string, boolean> = {};
  private moveJoystick = { x: 0, y: 0 };
  private isMouseDown = false;
  private prevMouseX = 0;
  private prevMouseY = 0;

  // Camera lerp targets
  private camCurrentPos = new THREE.Vector3();
  private camTargetPos = new THREE.Vector3();

  // Scratch helpers to avoid GC in loop
  private readonly _v1 = new THREE.Vector3();
  private readonly _v2 = new THREE.Vector3();

  constructor(container: HTMLDivElement, callbacks: GameEngineCallbacks) {
    this.container = container;
    this.callbacks = callbacks;
    this.director = new AIDirector(false);

    this.checkSoftwareGl();
    this.initThree();
    this.bindInputs();
  }

  private checkSoftwareGl() {
    try {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) {
        this.isSoftwareGl = true;
        return;
      }
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      this.isSoftwareGl = /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    } catch {
      this.isSoftwareGl = true;
    }
  }

  private initThree() {
    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(65, width / height, 0.1, 50);

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.0;
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.container.innerHTML = '';
    this.container.appendChild(this.renderer.domElement);

    // Initial scratch setup
    window.addEventListener('resize', this.onWindowResize);
  }

  public startLevel(level: LevelConfig, charId: CharacterId, difficulty: Difficulty, safeMode = false) {
    this.levelConfig = JSON.parse(JSON.stringify(level));
    this.characterId = charId;
    this.difficulty = difficulty;
    this.director.setSafeMode(safeMode);
    this.director.reset();

    // Reset player attributes
    this.sanity = 100;
    const charDef = CHARACTERS[charId];
    this.stamina = 100 * charDef.staminaMult;
    this.battery = 100;
    this.isFlashlightOn = true;
    this.lives = difficulty === 'MUDAH' ? 5 : difficulty === 'NORMAL' ? 3 : 1;
    this.score = 0;
    this.elapsedLevelTime = 0;
    this.isHiding = false;
    this.isHoldingBreath = false;
    this.isPossessed = false;
    this.skillCooldownTimer = 0;
    this.isFuseBoxOn = false;
    this.activeSaltCircle = null;
    this.visitedGridTiles.clear();
    this.collectedNotesThisRun = [];
    this.pianoInputNotes = [];
    this.ghostState = 'DORMANT';
    this.solvedRiddleIds.clear();
    this.activeRiddleTriggers = [];

    // Default Starting Items
    this.inventory = [
      { id: 'item_bat_1', type: 'BATTERY', name: 'Baterai ABC', icon: '🔋', count: 2, description: 'Mengisi ulang daya senter.' },
      { id: 'item_jimat_1', type: 'JIMAT', name: 'Jimat Rajah', icon: '📜', count: 1, description: 'Menyetrum hantu selama 5 detik.' },
      { id: 'item_garam_1', type: 'GARAM', name: 'Garam Suci', icon: '🧂', count: 1, description: 'Lingkaran pelindung hantu 10 detik.' },
      { id: 'item_botol_1', type: 'BOTTLE', name: 'Botol Kaca', icon: '🍾', count: 2, description: 'Lempar untuk mengecoh hantu.' },
      { id: 'item_air_1', type: 'AIR_DOA', name: 'Air Doa Mbah', icon: '💧', count: 1, description: 'Memulihkan 40% Keberanian.' },
    ];

    this.buildWorld();
    this.updateHUDAll();

    if (!this.animationFrameId) {
      this.clock.start();
      this.tick();
    }
  }

  private buildWorld() {
    // Clear old scene contents
    while (this.scene.children.length > 0) {
      const obj = this.scene.children[0];
      this.scene.remove(obj);
    }
    this.walls = [];
    this.interactiveDoors = [];
    this.hidingSpots = [];
    this.candleProps = [];
    this.pickupItems = [];

    // Atmosphere & Fog (Soft atmospheric mist, not blinding black void)
    this.scene.background = new THREE.Color(this.levelConfig.fogColor);
    this.scene.fog = new THREE.FogExp2(this.levelConfig.fogColor, this.levelConfig.fogDensity);

    // Moonlight Directional Key Light with soft shadows
    const moonLight = new THREE.DirectionalLight(0x7599c4, 1.4);
    moonLight.position.set(16, 22, 14);
    moonLight.castShadow = !this.isSoftwareGl;
    moonLight.shadow.mapSize.width = 1024;
    moonLight.shadow.mapSize.height = 1024;
    moonLight.shadow.bias = -0.0005;
    this.scene.add(moonLight);

    // Ambient Environmental Fill
    const hemiLight = new THREE.HemisphereLight(0x5a708c, 0x1f2328, 0.9);
    this.scene.add(hemiLight);

    // Player Mesh Rig
    this.playerRig = createPlayerModel(this.characterId);
    this.scene.add(this.playerRig.root);

    // Flashlight SpotLight and High-Intensity Bulb Glow
    this.flashlightTarget = new THREE.Object3D();
    this.scene.add(this.flashlightTarget);

    const flashIntensity = this.characterId === 'joko' ? 10.0 : 7.5;
    this.flashlightSpot = new THREE.SpotLight(0xfff7e6, flashIntensity, 32, Math.PI / 3.6, 0.4, 1.0);
    this.flashlightSpot.castShadow = !this.isSoftwareGl;
    this.flashlightSpot.shadow.bias = -0.0005;
    this.flashlightSpot.target = this.flashlightTarget;
    this.scene.add(this.flashlightSpot);

    // Local bulb glow to illuminate surrounding floor, walls, and character
    const bulbGlow = new THREE.PointLight(0xffe8ba, 2.5, 9.0);
    bulbGlow.name = 'flashlight_bulb';
    this.flashlightSpot.add(bulbGlow);

    // Floating Cinematic Dust Particles
    const dust = createDustParticles(180);
    this.scene.add(dust);

    // Build Floor, Ceiling Beams, and Walls from Grid
    this.grid = this.levelConfig.grid;
    const rows = this.grid.length;
    const cols = this.grid[0].length;

    // Rich Wooden Planks Floor
    const floorTexture = getProceduralTexture(this.levelConfig.id === 1 ? 'WOOD_FLOOR' : this.levelConfig.id === 2 ? 'WALL_COLONIAL' : 'TILES_DIRTY');
    floorTexture.repeat.set(cols / 2, rows / 2);
    const floorMat = new THREE.MeshStandardMaterial({
      map: floorTexture,
      roughness: 0.7,
      metalness: 0.15,
    });
    const floorGeom = new THREE.PlaneGeometry(cols * 2, rows * 2);
    const floor = new THREE.Mesh(floorGeom, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.position.set((cols * 2) / 2, 0, (rows * 2) / 2);
    floor.receiveShadow = !this.isSoftwareGl;
    this.scene.add(floor);

    // Overhead Wooden Ceiling Beams (Kaso & Balok Plafon)
    const beamMat = new THREE.MeshStandardMaterial({ map: getProceduralTexture('WOOD_FLOOR'), roughness: 0.8 });
    for (let bx = 2; bx < cols * 2; bx += 4) {
      const beam = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.35, rows * 2), beamMat);
      beam.position.set(bx, 3.2, (rows * 2) / 2);
      this.scene.add(beam);
    }

    // Wall Material with Vertical Slats & Trim
    const wallTexture = getProceduralTexture(this.levelConfig.id === 1 ? 'WALL_WOOD' : this.levelConfig.id === 2 ? 'WALL_COLONIAL' : 'TILES_DIRTY');
    const wallMat = new THREE.MeshStandardMaterial({
      map: wallTexture,
      roughness: 0.85,
      metalness: 0.05,
    });
    const wallGeom = new THREE.BoxGeometry(2, 3.2, 2);

    let keyIndex = 1;
    let noteIndex = 0;

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const char = this.grid[r][c];
        const wx = c * 2 + 1;
        const wz = r * 2 + 1;

        if (char === 'W') {
          // Solid Wall block
          const wallMesh = new THREE.Mesh(wallGeom, wallMat);
          wallMesh.position.set(wx, 1.6, wz);
          wallMesh.castShadow = !this.isSoftwareGl;
          wallMesh.receiveShadow = !this.isSoftwareGl;
          this.scene.add(wallMesh);

          const box = new THREE.Box3().setFromObject(wallMesh);
          this.walls.push(box);
        } else if (char === 'S') {
          // Player Spawn (Face open doorway into living room)
          this.playerX = wx;
          this.playerZ = wz;
          this.playerRotY = -Math.PI / 2;
        } else if (char === 'G') {
          // Ghost Spawn
          this.ghostX = wx;
          this.ghostZ = wz;
          this.ghostTargetX = wx;
          this.ghostTargetZ = wz;
        } else if (char === 'D') {
          // Door
          const door = createDoor();
          door.frameGroup.position.set(wx, 0, wz);
          this.scene.add(door.frameGroup);
          this.interactiveDoors.push({
            frame: door.frameGroup,
            pivot: door.doorPivot,
            isOpen: false,
            x: wx,
            z: wz,
          });
        } else if (char === 'H') {
          // Hiding Spot: Antique Carved Wardrobe (Lemari Jati)
          const wardrobe = createWardrobe();
          wardrobe.position.set(wx, 0, wz);
          this.scene.add(wardrobe);
          this.hidingSpots.push({ mesh: wardrobe, x: wx, z: wz });
        } else if (char === 'T') {
          // Dining Table & Chairs with tea set
          const tableSet = createTableAndChairs();
          tableSet.position.set(wx, 0, wz);
          this.scene.add(tableSet);
        } else if (char === 'B') {
          // Antique Javanese Bed with pillow and batik blanket
          const bed = createAntiqueBed();
          bed.position.set(wx, 0, wz);
          this.scene.add(bed);
          this.hidingSpots.push({ mesh: bed, x: wx, z: wz });
        } else if (char === 'A') {
          // Altar Sesajen with offerings and incense
          const altar = createAltarSesajen();
          altar.position.set(wx, 0, wz);
          this.scene.add(altar);

          // Associate first story riddle with Altar Sesajen
          if (this.levelConfig.riddles && this.levelConfig.riddles[0]) {
            this.activeRiddleTriggers.push({
              riddle: this.levelConfig.riddles[0],
              x: wx,
              z: wz,
            });
          }
        } else if (char === 'C') {
          // Candle Checkpoint with warm point light
          const candle = createCandleCheckpoint();
          candle.group.position.set(wx, 0, wz);
          this.scene.add(candle.group);
          this.candleProps.push({
            light: candle.light,
            flame: candle.flame,
            x: wx,
            z: wz,
            isLit: true,
            burnTime: 45,
          });
        } else if (char === 'K') {
          // Mission Item: Keys / Sheet Music / Medical Records
          const itemType = this.levelConfig.id === 1 ? 'KEY_PADLOCK' : this.levelConfig.id === 2 ? 'NOTE_SHEET' : 'MEDICAL_RECORD';
          const itemName = this.levelConfig.id === 1 ? `Kunci Gembok #${keyIndex++}` : this.levelConfig.id === 2 ? `Partitur Not #${keyIndex++}` : `Rekam Medis #${keyIndex++}`;
          this.spawnWorldPickup(wx, wz, itemType, itemName);
        } else if (char === 'N') {
          // Lore Note
          if (noteIndex < this.levelConfig.loreNotes.length) {
            const noteObj = this.levelConfig.loreNotes[noteIndex++];
            this.spawnWorldPickup(wx, wz, 'LORE_NOTE', noteObj.title, noteObj.id);
          }
        } else if (char === 'P') {
          // Piano for Level 2
          this.pianoMesh = createGrandPiano();
          this.pianoMesh.position.set(wx, 0, wz);
          this.scene.add(this.pianoMesh);
        } else if (char === 'F') {
          // Fuse Box for Level 2
          this.fuseBoxMesh = createFuseBox();
          this.fuseBoxMesh.position.set(wx, 0, wz);
          this.scene.add(this.fuseBoxMesh);
        }
      }
    }

    // Spawn secondary story riddle (e.g. Peti Kayu Pusaka) if configured
    if (this.levelConfig.riddles && this.levelConfig.riddles.length > 1) {
      const secondRiddle = this.levelConfig.riddles[1];
      const chestX = 17;
      const chestZ = 7;
      const chestGeom = new THREE.BoxGeometry(0.75, 0.55, 0.45);
      const chestMat = new THREE.MeshStandardMaterial({
        color: 0x45220d,
        roughness: 0.7,
        metalness: 0.2,
      });
      const chestMesh = new THREE.Mesh(chestGeom, chestMat);
      chestMesh.position.set(chestX, 0.28, chestZ);
      this.scene.add(chestMesh);

      const chestLight = new THREE.PointLight(0xf59e0b, 1.4, 2.5);
      chestLight.position.set(chestX, 0.65, chestZ);
      this.scene.add(chestLight);

      this.activeRiddleTriggers.push({
        riddle: secondRiddle,
        x: chestX,
        z: chestZ,
      });
    }

    // Atmospheric Hanging Kerosene Lamps (Lampu Petromak) in Rooms
    const lanternPositions = [
      { x: 5, z: 5 },
      { x: 13, z: 5 },
      { x: 7, z: 15 },
      { x: 21, z: 15 },
      { x: 13, z: 21 },
    ];
    for (const lp of lanternPositions) {
      const { group: lampGroup } = createKeroseneLamp();
      lampGroup.position.set(lp.x, 2.4, lp.z);
      this.scene.add(lampGroup);

      // Ancestor Portrait on nearby wall
      const portrait = createPortraitPainting();
      portrait.position.set(lp.x, 2.0, lp.z - 1.95);
      this.scene.add(portrait);
    }

    // Spawn Ghost Mesh
    if (this.levelConfig.ghostType === 'POCONG') {
      this.ghostMesh = createPocongModel();
    } else if (this.levelConfig.ghostType === 'NONI_BELANDA') {
      this.ghostMesh = createNoniBelandaModel();
    } else {
      this.ghostMesh = createSusterNgesotModel();
    }
    this.ghostMesh.position.set(this.ghostX, 0, this.ghostZ);
    // When DORMANT, ghost is silent and not active
    this.ghostMesh.visible = this.ghostState !== 'DORMANT';
    this.scene.add(this.ghostMesh);

    // Position player
    this.playerRig.root.position.set(this.playerX, 0, this.playerZ);
    this.playerRig.root.rotation.y = this.playerRotY;
  }

  private spawnWorldPickup(x: number, z: number, type: string, name: string, loreNoteId?: string) {
    const group = new THREE.Group();
    group.name = `pickup_${type}`;

    let geom: THREE.BufferGeometry;
    let mat: THREE.Material;

    if (type === 'KEY_PADLOCK' || type === 'KEY_GATE') {
      geom = new THREE.TorusGeometry(0.09, 0.025, 6, 8);
      mat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.3, metalness: 0.9 });
    } else if (type === 'NOTE_SHEET' || type === 'MEDICAL_RECORD' || type === 'LORE_NOTE') {
      geom = new THREE.BoxGeometry(0.2, 0.02, 0.28);
      mat = new THREE.MeshStandardMaterial({ color: 0xfef3c7, roughness: 0.9 });
    } else {
      geom = new THREE.CylinderGeometry(0.04, 0.04, 0.15, 6);
      mat = new THREE.MeshStandardMaterial({ color: 0x3b82f6, roughness: 0.4 });
    }

    const mesh = new THREE.Mesh(geom, mat);
    mesh.position.y = 0.35;
    mesh.castShadow = !this.isSoftwareGl;
    group.add(mesh);

    // Subtle gentle glow point
    const glow = new THREE.PointLight(0xffffff, 0.6, 2.5);
    glow.position.y = 0.5;
    group.add(glow);

    group.position.set(x, 0, z);
    this.scene.add(group);

    this.pickupItems.push({
      id: loreNoteId || `item_${Math.random().toString(36).substring(2, 7)}`,
      mesh: group,
      x,
      z,
      type,
      name,
      collected: false,
    });
  }

  // --- Input Bindings ---
  private bindInputs() {
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('mousemove', this.onMouseMove);
    window.addEventListener('mousedown', this.onMouseDown);
    window.addEventListener('mouseup', this.onMouseUp);
  }

  private onKeyDown = (e: KeyboardEvent) => {
    this.keysPressed[e.code] = true;

    // Toggle Flashlight [F]
    if (e.code === 'KeyF') {
      this.toggleFlashlight();
    }
    // Change Camera [V]
    if (e.code === 'KeyV') {
      this.cycleCamera();
    }
    // Interact [E]
    if (e.code === 'KeyE') {
      this.performInteraction();
    }
    // Reload Battery [R]
    if (e.code === 'KeyR') {
      this.useItemByType('BATTERY');
    }
    // Jimat [Q]
    if (e.code === 'KeyQ') {
      this.useItemByType('JIMAT');
    }
    // Garam [G]
    if (e.code === 'KeyG') {
      this.useItemByType('GARAM');
    }
    // Throw Bottle [T]
    if (e.code === 'KeyT') {
      this.useItemByType('BOTTLE');
    }
    // Air Doa [H]
    if (e.code === 'KeyH') {
      this.useItemByType('AIR_DOA');
    }
    // Character Skill [X]
    if (e.code === 'KeyX') {
      this.triggerCharacterSkill();
    }
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keysPressed[e.code] = false;
  };

  private onMouseDown = (e: MouseEvent) => {
    if (e.button === 0) {
      this.isMouseDown = true;
      this.prevMouseX = e.clientX;
      this.prevMouseY = e.clientY;
      soundManager.resume();
    }
  };

  private onMouseUp = () => {
    this.isMouseDown = false;
  };

  private onMouseMove = (e: MouseEvent) => {
    // If pointer locked OR mouse dragged
    const isLocked = document.pointerLockElement === this.container || document.pointerLockElement === this.renderer.domElement;
    if (isLocked) {
      const sensitivity = 0.0022;
      this.playerRotY -= e.movementX * sensitivity;
      this.playerPitch -= e.movementY * sensitivity;
      this.playerPitch = Math.max(-Math.PI / 3, Math.min(Math.PI / 3, this.playerPitch));
    } else if (this.isMouseDown) {
      const dx = e.clientX - this.prevMouseX;
      const dy = e.clientY - this.prevMouseY;
      this.prevMouseX = e.clientX;
      this.prevMouseY = e.clientY;

      const sensitivity = 0.004;
      this.playerRotY -= dx * sensitivity;
      this.playerPitch -= dy * sensitivity;
      this.playerPitch = Math.max(-Math.PI / 3, Math.min(Math.PI / 3, this.playerPitch));
    }
  };

  // Mobile virtual joystick & drag look
  public setJoystickVector(vx: number, vy: number) {
    this.moveJoystick.x = vx;
    this.moveJoystick.y = vy;
  }

  public handleTouchLookDelta(dx: number, dy: number) {
    const sensitivity = 0.0045;
    this.playerRotY -= dx * sensitivity;
    this.playerPitch -= dy * sensitivity;
    this.playerPitch = Math.max(-Math.PI / 3, Math.min(Math.PI / 3, this.playerPitch));
  }

  // --- Actions ---
  public toggleFlashlight() {
    this.isFlashlightOn = !this.isFlashlightOn;
    this.flashlightSpot.visible = this.isFlashlightOn;
    soundManager.playFlashlightClick();
  }

  public cycleCamera() {
    if (this.cameraMode === 'FIRST_PERSON') {
      this.cameraMode = 'THIRD_PERSON';
    } else if (this.cameraMode === 'THIRD_PERSON') {
      this.cameraMode = 'TOP_DOWN';
    } else {
      this.cameraMode = 'FIRST_PERSON';
    }
    this.callbacks.onCameraChange(this.cameraMode);
  }

  public setCameraMode(mode: CameraMode) {
    this.cameraMode = mode;
    this.callbacks.onCameraChange(this.cameraMode);
  }

  public useItemByType(type: string): boolean {
    const itemIndex = this.inventory.findIndex((it) => it.type === type && it.count > 0);
    if (itemIndex === -1) return false;

    const item = this.inventory[itemIndex];

    if (type === 'BATTERY') {
      this.battery = Math.min(100, this.battery + 60);
      soundManager.playFlashlightClick();
      this.callbacks.onBatteryChange(this.battery);
    } else if (type === 'AIR_DOA') {
      this.sanity = Math.min(100, this.sanity + 40);
      soundManager.playItemPickup();
      this.callbacks.onSanityChange(this.sanity);
    } else if (type === 'JIMAT') {
      // Stun ghost
      this.ghostState = 'STUN';
      this.ghostStunTimer = 5.0;
      soundManager.playItemPickup();
      this.callbacks.onParanormalNotification('Jimat bercahaya! Hantu terpukul mundur!');
    } else if (type === 'GARAM') {
      // Deploy salt barrier ring for 10s
      this.deploySaltCircle();
      this.callbacks.onParanormalNotification('Garam Suci ditabur! Membentuk lingkaran pelindung.');
    } else if (type === 'BOTTLE') {
      // Throw bottle forward 7m as noise decoy
      const throwDist = 7.0;
      const targetX = this.playerX - Math.sin(this.playerRotY) * throwDist;
      const targetZ = this.playerZ - Math.cos(this.playerRotY) * throwDist;
      soundManager.playBottleBreak(targetX - this.playerX, targetZ - this.playerZ);
      // Ghost investigates noise
      this.ghostTargetX = targetX;
      this.ghostTargetZ = targetZ;
      this.ghostState = 'INVESTIGATE';
      this.callbacks.onParanormalNotification('Prang! Botol pecah menarik perhatian hantu!');
    }

    item.count -= 1;
    if (item.count <= 0) {
      this.inventory.splice(itemIndex, 1);
    }
    this.callbacks.onInventoryChange([...this.inventory]);
    return true;
  }

  private deploySaltCircle() {
    if (this.activeSaltCircle) {
      this.scene.remove(this.activeSaltCircle.mesh);
    }
    const ringGeom = new THREE.RingGeometry(2.8, 3.0, 32);
    const ringMat = new THREE.MeshBasicMaterial({ color: 0xffffff, side: THREE.DoubleSide });
    const ringMesh = new THREE.Mesh(ringGeom, ringMat);
    ringMesh.rotation.x = -Math.PI / 2;
    ringMesh.position.set(this.playerX, 0.02, this.playerZ);
    this.scene.add(ringMesh);

    this.activeSaltCircle = {
      mesh: ringMesh,
      x: this.playerX,
      z: this.playerZ,
      expireTime: this.elapsedLevelTime + 10,
    };
  }

  public triggerCharacterSkill() {
    if (this.skillCooldownTimer > 0) return;
    const char = CHARACTERS[this.characterId];
    this.skillCooldownTimer = char.skillCooldown;

    if (this.characterId === 'raka') {
      // Fast Dash
      this.stamina = Math.min(100, this.stamina + 20);
      this.callbacks.onParanormalNotification('Lari Kilat aktif!');
    } else if (this.characterId === 'sari') {
      // Tarik Napas: +30% Sanity
      this.sanity = Math.min(100, this.sanity + 30);
      this.callbacks.onSanityChange(this.sanity);
      this.callbacks.onParanormalNotification('Tarik Napas: Keberanian dipulihkan!');
    } else if (this.characterId === 'joko') {
      // Sorot Terang: Stun ghost in front for 2s
      this.ghostState = 'STUN';
      this.ghostStunTimer = 2.0;
      soundManager.playFlashlightClick();
      this.callbacks.onParanormalNotification('Sorot Terang! Hantu terbutakan!');
    } else if (this.characterId === 'dewi') {
      // Mata Batin: outline ghost, costs 15% sanity
      this.sanity = Math.max(0, this.sanity - 15);
      this.callbacks.onSanityChange(this.sanity);
      this.callbacks.onParanormalNotification('Mata Batin aktif: Keberadaan gaib terungkap!');
    }
  }

  public playPianoKey(note: string) {
    soundManager.playPianoNote(note);
    this.pianoInputNotes.push(note);

    const targetMelody = ['C4', 'E4', 'G4', 'B4'];
    if (this.pianoInputNotes.length === targetMelody.length) {
      if (verifyPianoPuzzle(this.pianoInputNotes, targetMelody)) {
        soundManager.playItemPickup();
        this.callbacks.onParanormalNotification('Klak! Brankas rahasia di samping piano terbuka!');
        this.callbacks.onPianoPuzzleOpen(false);
        // Complete objective
        const obj = this.levelConfig.objectives.find((o) => o.id === 'piano');
        if (obj) obj.completed = true;
        this.spawnWorldPickup(this.playerX + 1, this.playerZ, 'KEY_GATE', 'Kunci Gerbang Utama');
        this.callbacks.onObjectiveUpdate([...this.levelConfig.objectives]);
      } else {
        this.callbacks.onParanormalNotification('Melodi salah... Terdengar desah lirih di cermin.');
        this.pianoInputNotes = [];
      }
    }
  }

  public setHoldingBreath(holding: boolean) {
    this.isHoldingBreath = holding;
  }

  // --- Interaction Check ---
  private performInteraction() {
    if (this.isHiding) {
      // Exit hiding spot
      this.isHiding = false;
      this.callbacks.onHidingStateChange(false);
      this.callbacks.onParanormalNotification('Keluar dari persembunyian.');
      return;
    }

    // Check pickups within 2m
    for (let i = 0; i < this.pickupItems.length; i++) {
      const item = this.pickupItems[i];
      if (item.collected) continue;
      const d = Math.hypot(item.x - this.playerX, item.z - this.playerZ);
      if (d < 1.8) {
        item.collected = true;
        this.scene.remove(item.mesh);
        soundManager.playItemPickup();

        if (item.type === 'LORE_NOTE') {
          const noteData = this.levelConfig.loreNotes.find((n) => n.id === item.id);
          if (noteData) {
            noteData.found = true;
            this.collectedNotesThisRun.push(noteData.id);
            this.callbacks.onNoteFound(noteData);
          }
        } else {
          // Add to inventory
          const existing = this.inventory.find((inv) => inv.type === item.type);
          if (existing) {
            existing.count += 1;
          } else {
            this.inventory.push({
              id: item.id,
              type: item.type as any,
              name: item.name,
              icon: item.type.includes('KEY') ? '🔑' : '📄',
              count: 1,
              description: item.name,
            });
          }
          this.callbacks.onInventoryChange([...this.inventory]);

          // Update level objective counters
          if (item.type === 'KEY_PADLOCK') {
            const obj = this.levelConfig.objectives.find((o) => o.id === 'keys');
            if (obj) {
              obj.current += 1;
              if (obj.current >= obj.required) obj.completed = true;
            }
          } else if (item.type === 'NOTE_SHEET') {
            const obj = this.levelConfig.objectives.find((o) => o.id === 'sheets');
            if (obj) {
              obj.current += 1;
              if (obj.current >= obj.required) obj.completed = true;
            }
          } else if (item.type === 'MEDICAL_RECORD') {
            const obj = this.levelConfig.objectives.find((o) => o.id === 'records');
            if (obj) {
              obj.current += 1;
              if (obj.current >= obj.required) obj.completed = true;
            }
          }
          this.callbacks.onObjectiveUpdate([...this.levelConfig.objectives]);
        }
        return;
      }
    }

    // Check Story Riddles (Altar Sesajen & Peti Pusaka) within 2.2m
    for (const trigger of this.activeRiddleTriggers) {
      if (!this.solvedRiddleIds.has(trigger.riddle.id)) {
        const dist = Math.hypot(trigger.x - this.playerX, trigger.z - this.playerZ);
        if (dist < 2.2) {
          this.callbacks.onOpenRiddle(trigger.riddle);
          return;
        }
      }
    }

    // Check Doors within 2.2m
    for (const d of this.interactiveDoors) {
      const dist = Math.hypot(d.x - this.playerX, d.z - this.playerZ);
      if (dist < 2.0) {
        d.isOpen = !d.isOpen;
        d.pivot.rotation.y = d.isOpen ? Math.PI / 2 : 0;
        soundManager.playDoorCreak();
        return;
      }
    }

    // Check Wardrobes / Hiding spots within 2.0m
    for (const h of this.hidingSpots) {
      const dist = Math.hypot(h.x - this.playerX, h.z - this.playerZ);
      if (dist < 2.0) {
        this.isHiding = true;
        this.playerX = h.x;
        this.playerZ = h.z;
        this.callbacks.onHidingStateChange(true);
        this.callbacks.onParanormalNotification('Bersembunyi... Tahan Napas jika hantu memeriksa!');
        return;
      }
    }

    // Check Piano in Level 2
    if (this.pianoMesh) {
      const dist = Math.hypot(this.pianoMesh.position.x - this.playerX, this.pianoMesh.position.z - this.playerZ);
      if (dist < 2.5) {
        this.callbacks.onPianoPuzzleOpen(true);
        return;
      }
    }

    // Check Fuse Box in Level 2
    if (this.fuseBoxMesh) {
      const dist = Math.hypot(this.fuseBoxMesh.position.x - this.playerX, this.fuseBoxMesh.position.z - this.playerZ);
      if (dist < 2.2) {
        this.isFuseBoxOn = true;
        soundManager.playFlashlightClick();
        this.callbacks.onParanormalNotification('Listrik Villa menyala! Lampu kristal menerangi lorong.');
        const obj = this.levelConfig.objectives.find((o) => o.id === 'fuse');
        if (obj) obj.completed = true;
        this.callbacks.onObjectiveUpdate([...this.levelConfig.objectives]);
        return;
      }
    }

    // Check Exit / Escape condition at edge doors
    const escapeObj = this.levelConfig.objectives.find((o) => o.id === 'escape');
    if (escapeObj) {
      const canEscape = this.levelConfig.objectives.filter((o) => o.id !== 'escape').every((o) => o.completed);
      if (canEscape) {
        const distToStart = Math.hypot(this.playerX - 3, this.playerZ - 3);
        if (distToStart < 3.0) {
          escapeObj.completed = true;
          this.finishLevel(true);
        }
      }
    }
  }

  // --- Main Tick Loop ---
  private tick = () => {
    if (this.isDisposed) return;
    const rawDelta = this.clock.getDelta();
    const delta = Math.min(rawDelta, 0.05); // clamped

    if (!this.isPaused) {
      this.updateSimulation(delta);
    }

    this.renderScene();
    this.animationFrameId = requestAnimationFrame(this.tick);
  };

  private updateSimulation(delta: number) {
    this.elapsedLevelTime += delta;
    if (this.skillCooldownTimer > 0) {
      this.skillCooldownTimer -= delta;
    }

    // Drain Flashlight battery slowly
    if (this.isFlashlightOn) {
      const charDef = CHARACTERS[this.characterId];
      const drainRate = this.characterId === 'joko' ? 0.35 : 0.55;
      this.battery = Math.max(0, this.battery - drainRate * delta);
      if (this.battery <= 0 && this.flashlightSpot.visible) {
        this.flashlightSpot.visible = false;
        this.callbacks.onParanormalNotification('Baterai senter habis! Tekan [R] untuk ganti baterai.');
      }
      this.callbacks.onBatteryChange(this.battery);
    }

    // Check Active Salt Circle
    if (this.activeSaltCircle && this.elapsedLevelTime >= this.activeSaltCircle.expireTime) {
      this.scene.remove(this.activeSaltCircle.mesh);
      this.activeSaltCircle = null;
    }

    // Player Movement physics (if not hiding)
    let moveSpeed = 0;
    if (!this.isHiding) {
      const charDef = CHARACTERS[this.characterId];
      const isShift = this.keysPressed['ShiftLeft'] || this.keysPressed['ShiftRight'];
      const isCrouch = this.keysPressed['KeyC'];

      let baseSpeed = 2.8 * charDef.speedMult;
      if (isShift && this.stamina > 5) {
        baseSpeed = 5.4 * charDef.speedMult;
      } else if (isCrouch) {
        baseSpeed = 1.4;
      }

      // Input directions
      let moveForward = 0;
      let moveSide = 0;
      if (this.keysPressed['KeyW'] || this.keysPressed['ArrowUp']) moveForward += 1;
      if (this.keysPressed['KeyS'] || this.keysPressed['ArrowDown']) moveForward -= 1;
      if (this.keysPressed['KeyA'] || this.keysPressed['ArrowLeft']) moveSide -= 1;
      if (this.keysPressed['KeyD'] || this.keysPressed['ArrowRight']) moveSide += 1;

      // Virtual joystick blend
      if (Math.abs(this.moveJoystick.y) > 0.1) moveForward -= this.moveJoystick.y;
      if (Math.abs(this.moveJoystick.x) > 0.1) moveSide += this.moveJoystick.x;

      // Kerasukan reversed controls if sanity is 0
      if (this.isPossessed) {
        moveForward = -moveForward;
        moveSide = -moveSide;
        this.possessedTimer -= delta;
        if (this.possessedTimer <= 0) {
          this.isPossessed = false;
        }
      }

      const inputLen = Math.hypot(moveForward, moveSide);
      if (inputLen > 0.05) {
        const dirForward = moveForward / inputLen;
        const dirSide = moveSide / inputLen;

        const sinRot = Math.sin(this.playerRotY);
        const cosRot = Math.cos(this.playerRotY);

        const dx = (-sinRot * dirForward + cosRot * dirSide) * baseSpeed * delta;
        const dz = (-cosRot * dirForward - sinRot * dirSide) * baseSpeed * delta;

        // Collision check with walls
        this.attemptMovePlayer(dx, dz);
        moveSpeed = baseSpeed;

        // Footstep audio
        const surface = this.levelConfig.id === 1 ? 'WOOD' : this.levelConfig.id === 2 ? 'MARBLE' : 'TILE';
        if (this.clock.getElapsedTime() - this.lastGhostFootstepTime > (isShift ? 0.32 : 0.55)) {
          this.lastGhostFootstepTime = this.clock.getElapsedTime();
          soundManager.playFootstep(surface, isShift);
        }
      }

      // Update stamina
      this.stamina = updateStamina(this.stamina, isShift && inputLen > 0.1, isCrouch, this.isHoldingBreath, delta, 100 * charDef.staminaMult);
      this.callbacks.onStaminaChange(this.stamina);
    }

    // Distance to ghost
    const distToGhost = Math.hypot(this.ghostX - this.playerX, this.ghostZ - this.playerZ);

    // Update Sanity
    const charDef = CHARACTERS[this.characterId];
    const isNearCandle = this.candleProps.some((c) => c.isLit && Math.hypot(c.x - this.playerX, c.z - this.playerZ) < 3.0);
    this.sanity = updateSanity(
      this.sanity,
      !this.isFlashlightOn && !isNearCandle,
      distToGhost,
      distToGhost < 8.0,
      isNearCandle,
      delta,
      charDef.sanityRecoveryMult
    );
    this.callbacks.onSanityChange(this.sanity);
    soundManager.updateHeartbeat(this.sanity);

    if (this.sanity <= 0 && !this.isPossessed) {
      this.isPossessed = true;
      this.possessedTimer = 8.0;
      this.callbacks.onParanormalNotification('KERASUKAN! Kontrol terbalik dan hantu mengetahui posisimu!');
    }

    // AI Director update
    const isGhostChasing = this.ghostState === 'CHASE';
    const { directGhostToPlayer, paranormalEvent } = this.director.update(delta, isGhostChasing, distToGhost);
    if (directGhostToPlayer && this.ghostState === 'PATROL') {
      this.ghostTargetX = this.playerX + (Math.random() - 0.5) * 4;
      this.ghostTargetZ = this.playerZ + (Math.random() - 0.5) * 4;
    }
    if (paranormalEvent && paranormalEvent.message) {
      this.callbacks.onParanormalNotification(paranormalEvent.message);
    }

    // Flashlight flicker when ghost is close
    if (distToGhost < 8.0 && this.isFlashlightOn && Math.random() < 0.12) {
      this.flashlightSpot.intensity = Math.random() * 0.8;
    } else if (this.isFlashlightOn) {
      this.flashlightSpot.intensity = this.characterId === 'joko' ? 3.2 : 2.4;
    }

    // Ghost Simulation
    this.updateGhostAI(delta, moveSpeed);

    // Audio listener update
    soundManager.updateListenerPosition(
      this.playerX,
      1.65,
      this.playerZ,
      -Math.sin(this.playerRotY),
      -Math.cos(this.playerRotY)
    );

    // Threat audio layer update
    if (this.ghostState === 'CHASE') {
      soundManager.setThreatLevel('CHASE');
    } else if (distToGhost < 10.0) {
      soundManager.setThreatLevel('TENSE');
    } else {
      soundManager.setThreatLevel('CALM');
    }

    // Update Visited Grid Tiles for Minimap
    const gridX = Math.floor(this.playerX / 2);
    const gridZ = Math.floor(this.playerZ / 2);
    this.visitedGridTiles.add(`${gridX},${gridZ}`);

    // Update interaction prompt in view
    this.updateInteractionPrompt();
  }

  private attemptMovePlayer(dx: number, dz: number) {
    const nextX = this.playerX + dx;
    const nextZ = this.playerZ + dz;

    // Solid collision with player radius 0.42m against all walls
    const playerRadius = 0.42;
    let canMoveX = true;
    let canMoveZ = true;

    for (const box of this.walls) {
      if (checkCircleBoxCollision(nextX, this.playerZ, playerRadius, box.min.x, box.max.x, box.min.z, box.max.z)) {
        canMoveX = false;
      }
      if (checkCircleBoxCollision(this.playerX, nextZ, playerRadius, box.min.x, box.max.x, box.min.z, box.max.z)) {
        canMoveZ = false;
      }
    }

    // Solid collision with closed doors (Must open door with [E] to pass)
    for (const d of this.interactiveDoors) {
      if (!d.isOpen) {
        if (checkCircleBoxCollision(nextX, this.playerZ, playerRadius, d.x - 0.95, d.x + 0.95, d.z - 0.4, d.z + 0.4)) {
          canMoveX = false;
        }
        if (checkCircleBoxCollision(this.playerX, nextZ, playerRadius, d.x - 0.95, d.x + 0.95, d.z - 0.4, d.z + 0.4)) {
          canMoveZ = false;
        }
      }
    }

    if (canMoveX) this.playerX = nextX;
    if (canMoveZ) this.playerZ = nextZ;

    // Keep within world bounds
    this.playerX = Math.max(1, Math.min(this.grid[0].length * 2 - 1, this.playerX));
    this.playerZ = Math.max(1, Math.min(this.grid.length * 2 - 1, this.playerZ));

    // Update 3D player mesh
    this.playerRig.root.position.set(this.playerX, 0, this.playerZ);
    this.playerRig.root.rotation.y = this.playerRotY;
  }

  private updateGhostAI(delta: number, playerSpeed: number) {
    if (!this.ghostMesh) return;

    // Dormant Ghost State: Ghost rests quietly until player triggers awakening via lore/keys/riddles
    if (this.ghostState === 'DORMANT') {
      const foundNotesCount = this.collectedNotesThisRun.length;
      const foundKeysCount = this.inventory.filter((i) => i.type.includes('KEY')).reduce((acc, i) => acc + i.count, 0);
      const solvedRiddlesCount = this.solvedRiddleIds.size;

      if (shouldAwakenGhost(foundNotesCount, foundKeysCount, solvedRiddlesCount)) {
        this.ghostState = 'PATROL';
        this.ghostMesh.visible = true;
        soundManager.playJumpscareStinger();
        this.callbacks.onParanormalNotification('⚠️ Arwah Mbah Karto BANGKIT dari kuburnya! Berhati-hatilah!');
      } else {
        this.ghostMesh.visible = false;
        return;
      }
    }

    if (this.ghostState === 'STUN') {
      this.ghostStunTimer -= delta;
      if (this.ghostStunTimer <= 0) {
        this.ghostState = 'SEARCH';
        this.ghostTimer = 6.0;
      }
      return;
    }

    const distToPlayer = Math.hypot(this.ghostX - this.playerX, this.ghostZ - this.playerZ);

    // Detection check
    const saltDist = this.activeSaltCircle ? Math.hypot(this.ghostX - this.activeSaltCircle.x, this.ghostZ - this.activeSaltCircle.z) : 999;
    const detection = evaluateGhostDetection(
      this.levelConfig.ghostType,
      distToPlayer,
      playerSpeed,
      distToPlayer < 12.0,
      this.isFlashlightOn,
      distToPlayer < 8.0,
      this.keysPressed['KeyC'] || false,
      saltDist
    );

    // If ghost is Noni Belanda and illuminated by flashlight, freeze!
    if (detection.frozen) {
      // Frozen in place
      return;
    }

    if (detection.detected && !this.isHiding) {
      this.ghostState = 'CHASE';
      this.ghostTargetX = this.playerX;
      this.ghostTargetZ = this.playerZ;
      this.callbacks.onGhostDetectedChange(true, distToPlayer);
    }

    // Speed calculation
    let ghostSpeed = 2.4;
    if (this.levelConfig.ghostType === 'POCONG') {
      ghostSpeed = this.ghostState === 'CHASE' ? 3.6 : 1.8;
    } else if (this.levelConfig.ghostType === 'NONI_BELANDA') {
      ghostSpeed = this.ghostState === 'CHASE' ? 4.2 : 2.6;
    } else if (this.levelConfig.ghostType === 'SUSTER_NGESOT') {
      ghostSpeed = this.ghostState === 'CHASE' ? 4.8 : 1.6;
    }

    // Ghost movement towards target
    const dx = this.ghostTargetX - this.ghostX;
    const dz = this.ghostTargetZ - this.ghostZ;
    const distToTarget = Math.hypot(dx, dz);

    if (distToTarget > 0.2) {
      const step = Math.min(distToTarget, ghostSpeed * delta);
      this.ghostX += (dx / distToTarget) * step;
      this.ghostZ += (dz / distToTarget) * step;

      // Face target
      const angle = Math.atan2(dx, dz);
      this.ghostMesh.rotation.y = angle;
    }

    // Ghost Procedural Audio & Animation
    this.ghostHopAnim += delta * (this.ghostState === 'CHASE' ? 6 : 3);
    if (this.levelConfig.ghostType === 'POCONG') {
      // Hopping motion
      const hopHeight = Math.abs(Math.sin(this.ghostHopAnim)) * 0.45;
      this.ghostMesh.position.set(this.ghostX, hopHeight, this.ghostZ);

      if (Math.sin(this.ghostHopAnim) < -0.8 && distToPlayer < 20) {
        soundManager.playPocongHop(this.ghostX - this.playerX, this.ghostZ - this.playerZ);
      }
    } else if (this.levelConfig.ghostType === 'SUSTER_NGESOT') {
      // Crawling shake
      this.ghostMesh.position.set(this.ghostX, 0, this.ghostZ);
      if (Math.sin(this.ghostHopAnim) < -0.8 && distToPlayer < 18) {
        soundManager.playSusterCrawl(this.ghostX - this.playerX, this.ghostZ - this.playerZ);
      }
    } else {
      // Noni floating glide
      const floatY = 0.2 + Math.sin(this.ghostHopAnim * 0.5) * 0.15;
      this.ghostMesh.position.set(this.ghostX, floatY, this.ghostZ);
    }

    // Catch Check
    if (distToPlayer < 1.2 && !this.isHiding) {
      this.onPlayerCaught();
    }
  }

  private onPlayerCaught() {
    soundManager.playJumpscareStinger();
    this.lives -= 1;
    this.callbacks.onLivesChange(this.lives);

    if (this.lives <= 0) {
      this.callbacks.onGameOver('Doa pelindung habis... Arwahmu terikat di rumah angker keluarga Wirawan.');
    } else {
      this.callbacks.onParanormalNotification('Tertangkap! Mengulang di lilin pelindung...');
      // Respawn at starting point or near candle
      this.playerX = 3;
      this.playerZ = 3;
      this.ghostX = 14;
      this.ghostZ = 14;
      this.ghostState = 'PATROL';
      this.sanity = 60;
    }
  }

  private updateInteractionPrompt() {
    let prompt: string | null = null;

    // Check pickups
    for (const item of this.pickupItems) {
      if (!item.collected && Math.hypot(item.x - this.playerX, item.z - this.playerZ) < 1.8) {
        prompt = `[E] Ambil ${item.name}`;
        break;
      }
    }

    // Check doors
    if (!prompt) {
      for (const d of this.interactiveDoors) {
        if (Math.hypot(d.x - this.playerX, d.z - this.playerZ) < 2.0) {
          prompt = d.isOpen ? '[E] Tutup Pintu' : '[E] Buka Pintu';
          break;
        }
      }
    }

    // Check hiding spots
    if (!prompt) {
      for (const h of this.hidingSpots) {
        if (Math.hypot(h.x - this.playerX, h.z - this.playerZ) < 2.0) {
          prompt = this.isHiding ? '[E] Keluar Persembunyian' : '[E] Sembunyi di Lemari';
          break;
        }
      }
    }

    // Check piano
    if (!prompt && this.pianoMesh) {
      if (Math.hypot(this.pianoMesh.position.x - this.playerX, this.pianoMesh.position.z - this.playerZ) < 2.5) {
        prompt = '[E] Mainkan Piano Tua';
      }
    }

    // Check fuse box
    if (!prompt && this.fuseBoxMesh && !this.isFuseBoxOn) {
      if (Math.hypot(this.fuseBoxMesh.position.x - this.playerX, this.fuseBoxMesh.position.z - this.playerZ) < 2.2) {
        prompt = '[E] Nyalakan Sekring Listrik';
      }
    }

    // Check story riddles (Altar & Peti)
    if (!prompt) {
      for (const trigger of this.activeRiddleTriggers) {
        if (!this.solvedRiddleIds.has(trigger.riddle.id)) {
          if (Math.hypot(trigger.x - this.playerX, trigger.z - this.playerZ) < 2.2) {
            prompt = `[E] Pecahkan: ${trigger.riddle.title}`;
            break;
          }
        }
      }
    }

    this.callbacks.onInteractionPrompt(prompt);
  }

  public submitRiddleAnswer(riddleId: string, choiceIndex: number): { success: boolean; message: string; rewardItemName?: string } {
    const riddle = this.levelConfig.riddles?.find((r) => r.id === riddleId);
    if (!riddle) return { success: false, message: 'Teka-teki tidak ditemukan.' };

    if (checkRiddleAnswer(riddle.correctIndex, choiceIndex)) {
      this.solvedRiddleIds.add(riddleId);
      riddle.solved = true;
      soundManager.playItemPickup();

      let rewardIcon = '🔑';
      let itemType: any = 'KEY_PADLOCK';
      if (riddle.rewardItemName.includes('Jimat')) {
        rewardIcon = '📜';
        itemType = 'JIMAT';
      } else if (riddle.rewardItemName.includes('Air Doa')) {
        rewardIcon = '💧';
        itemType = 'AIR_DOA';
      } else if (riddle.rewardItemName.includes('Kunci')) {
        rewardIcon = '🔑';
        itemType = 'KEY_PADLOCK';
        const keyObj = this.levelConfig.objectives.find((o) => o.id === 'keys');
        if (keyObj) {
          keyObj.current = Math.min(keyObj.required, keyObj.current + 1);
          if (keyObj.current >= keyObj.required) keyObj.completed = true;
          this.callbacks.onObjectiveUpdate([...this.levelConfig.objectives]);
        }
      }

      const existing = this.inventory.find((i) => i.name === riddle.rewardItemName);
      if (existing) {
        existing.count += 1;
      } else {
        this.inventory.push({
          id: `reward_${riddle.id}`,
          type: itemType,
          name: riddle.rewardItemName,
          icon: rewardIcon,
          count: 1,
          description: `Hadiah pemecahan: ${riddle.title}`,
        });
      }
      this.callbacks.onInventoryChange([...this.inventory]);

      // Trigger ghost awakening if still dormant
      if (this.ghostState === 'DORMANT') {
        this.ghostState = 'PATROL';
        if (this.ghostMesh) this.ghostMesh.visible = true;
        soundManager.playJumpscareStinger();
        this.callbacks.onParanormalNotification('⚠️ Arwah Mbah Karto BANGKIT karena rahasianya terungkap! Cari pintu keluar!');
      } else {
        this.callbacks.onParanormalNotification(`Jawaban Benar! ${riddle.rewardItemName} ditambahkan ke tas.`);
      }

      return {
        success: true,
        message: `Benar! ${riddle.explanation}`,
        rewardItemName: riddle.rewardItemName,
      };
    } else {
      this.sanity = Math.max(10, this.sanity - 10);
      this.callbacks.onSanityChange(this.sanity);
      soundManager.playGhostWhisper(0, 0);
      return {
        success: false,
        message: 'Salah! Jawaban tidak sesuai dengan catatan arwah. Keberanianmu terguncang (-10%).',
      };
    }
  }

  private finishLevel(victory: boolean) {
    if (victory) {
      const multiplier = this.cameraMode === 'FIRST_PERSON' ? 1.5 : this.cameraMode === 'THIRD_PERSON' ? 1.2 : 1.0;
      const finalScore = Math.round(1500 * multiplier);
      this.callbacks.onLevelComplete(finalScore, 3, this.collectedNotesThisRun);
    }
  }

  private activeScreen = 'TITLE';

  public setScreen(screen: string) {
    this.activeScreen = screen;
  }

  // --- Camera & Rendering ---
  private renderScene() {
    // Menu / Character Select Showcase View
    if (this.activeScreen === 'TITLE' || this.activeScreen === 'CHAR_SELECT') {
      const time = this.clock.getElapsedTime();
      const radius = 3.6;
      const camX = this.playerX + Math.sin(time * 0.35) * radius;
      const camZ = this.playerZ + Math.cos(time * 0.35) * radius;

      this.camera.position.set(camX, 1.8 + Math.sin(time * 0.2) * 0.15, camZ);
      this.camera.lookAt(this.playerX, 1.25, this.playerZ);

      // Flashlight follows camera direction in menu
      this.flashlightSpot.position.set(this.playerX, 1.35, this.playerZ);
      this.flashlightTarget.position.set(this.playerX - Math.sin(time * 0.35) * 4, 1.0, this.playerZ - Math.cos(time * 0.35) * 4);

      // Slow character spin in menu
      this.playerRig.root.rotation.y = time * 0.45;
      this.playerRig.root.visible = true;

      this.renderer.render(this.scene, this.camera);
      return;
    }

    const sinRot = Math.sin(this.playerRotY);
    const cosRot = Math.cos(this.playerRotY);

    // Update flashlight light source position to match player chest/hand
    this.flashlightSpot.position.set(this.playerX, 1.35, this.playerZ);

    if (this.cameraMode === 'FIRST_PERSON') {
      // First person: Head level
      this.camTargetPos.set(this.playerX, 1.65, this.playerZ);
      this.camera.position.lerp(this.camTargetPos, 0.4);

      const lookTarget = this._v1.set(
        this.playerX - sinRot * Math.cos(this.playerPitch) * 10,
        1.65 + Math.sin(this.playerPitch) * 10,
        this.playerZ - cosRot * Math.cos(this.playerPitch) * 10
      );
      this.camera.lookAt(lookTarget);

      // Aim flashlight at look target
      this.flashlightTarget.position.copy(lookTarget);
      this.playerRig.root.visible = true; // arms & hands visible
      this.playerRig.root.rotation.y = this.playerRotY;
    } else if (this.cameraMode === 'THIRD_PERSON') {
      // Third person: 3m behind shoulder
      const behindDist = 3.2;
      const camX = this.playerX + sinRot * behindDist;
      const camZ = this.playerZ + cosRot * behindDist;
      const camY = 2.4 + Math.sin(this.playerPitch) * 1.5;

      this.camTargetPos.set(camX, camY, camZ);
      this.camera.position.lerp(this.camTargetPos, 0.2);

      const lookTarget = this._v1.set(this.playerX, 1.4, this.playerZ);
      this.camera.lookAt(lookTarget);

      this.flashlightTarget.position.set(this.playerX - sinRot * 10, 1.0, this.playerZ - cosRot * 10);
      this.playerRig.root.visible = true;
      this.playerRig.root.rotation.y = this.playerRotY;
    } else {
      // Top-Down: 14m above, angled down
      this.camTargetPos.set(this.playerX, 14.0, this.playerZ + 4.0);
      this.camera.position.lerp(this.camTargetPos, 0.15);
      this.camera.lookAt(this.playerX, 0, this.playerZ);

      this.flashlightTarget.position.set(this.playerX - sinRot * 10, 0, this.playerZ - cosRot * 10);
      this.playerRig.root.visible = true;
      this.playerRig.root.rotation.y = this.playerRotY;
    }

    this.renderer.render(this.scene, this.camera);
  }

  private onWindowResize = () => {
    if (!this.container || !this.renderer || !this.camera) return;
    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  private updateHUDAll() {
    this.callbacks.onSanityChange(this.sanity);
    const charDef = CHARACTERS[this.characterId];
    this.callbacks.onStaminaChange(this.stamina);
    this.callbacks.onBatteryChange(this.battery);
    this.callbacks.onInventoryChange([...this.inventory]);
    this.callbacks.onObjectiveUpdate([...this.levelConfig.objectives]);
    this.callbacks.onLivesChange(this.lives);
    this.callbacks.onScoreChange(this.score);
    this.callbacks.onCameraChange(this.cameraMode);
  }

  public getVisitedTiles(): Set<string> {
    return this.visitedGridTiles;
  }

  public getPlayerCoords() {
    return { x: this.playerX, z: this.playerZ, rotY: this.playerRotY };
  }

  public dispose() {
    this.isDisposed = true;
    if (this.animationFrameId) {
      cancelAnimationFrame(this.animationFrameId);
    }
    window.removeEventListener('resize', this.onWindowResize);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('mousemove', this.onMouseMove);
    window.removeEventListener('mousedown', this.onMouseDown);
    window.removeEventListener('mouseup', this.onMouseUp);

    this.renderer.dispose();
  }
}
